# The Adaptive Tutor API

A complete, in-memory fractions tutor backend built with the Next.js App Router and TypeScript. Reviewed lessons and practice questions are bundled in `lib/content/lesson.ts`; all learner state is held in a single `globalThis`-backed repository module. Data resets when the server process restarts. No database is required.

## Run locally

The repository is pinned to pnpm in `package.json`, so use the existing lockfile:

```bash
pnpm install
pnpm dev
```

The API is available at `http://localhost:3000/api`. No environment variables are required. To enable Anthropic-generated rephrasing, hints, and challenge judgments, copy `.env.example` to `.env.local` and provide an `ANTHROPIC_API_KEY`; optionally set `ANTHROPIC_MODEL`. Calls use an 8-second timeout, retry once, validate JSON, and fall back to the reviewed static copy if unavailable.

## Endpoints

| Method | Endpoint | Request | Response |
| --- | --- | --- | --- |
| POST | `/api/session` | `{ "name?": "Ari" }` | `{ sessionId }` |
| GET | `/api/diagnostic` | — | `{ questions }` (answer key included; option misconception tags removed) |
| POST | `/api/diagnostic/submit` | `{ sessionId, answers: [{ questionId, choice }] }` | `{ mastery, misconceptions, pathId, reason }` |
| GET | `/api/lesson/next?sessionId=...` | — | `{ step }`; practice step has prompt/options but no answer key |
| POST | `/api/answer` | `{ sessionId, questionId, choice, timeMs, hintsUsed }` | `{ correct, feedback, mastery, misconceptionTag?, nextAction, reason }` |
| GET | `/api/progress?sessionId=...` | — | `{ mastery, misconceptions, history, recommendation }` |
| POST | `/api/explain` | `{ sessionId, stepId, style }` | `{ explanation, source }` |
| POST | `/api/hint` | `{ sessionId, questionId, level }` | `{ hint, source }` |
| POST | `/api/challenge` | `{ sessionId, stepId, message }` | `{ verdict, reply, source }` |
| GET | `/api/health` | — | `{ status, storage, llmConfigured, sessions, uptimeSec }` |
| POST | `/api/demo/seed` | `{}` | `{ sessionId, mastery, misconceptions, pathId }` |

All `/api/*` responses include permissive CORS headers, and `OPTIONS` preflight returns 204. Validation errors use `{ "error": "...", "details": [...] }`; unknown sessions return 404. Requests are logged with timestamp, method, path/query, status, duration, source, and a 500-character body limit.

## Curl examples

```bash
# Create a learner
curl -sS -X POST http://localhost:3000/api/session \
  -H 'Content-Type: application/json' -d '{"name":"Ari"}'

# Fetch diagnostic questions
curl -sS http://localhost:3000/api/diagnostic

# Submit the eight diagnostic choices (choice IDs are a/b/c)
curl -sS -X POST http://localhost:3000/api/diagnostic/submit \
  -H 'Content-Type: application/json' \
  -d '{"sessionId":"s_example","answers":[{"questionId":"diag_equiv_1","choice":"a"},{"questionId":"diag_equiv_2","choice":"a"},{"questionId":"diag_compare_1","choice":"a"},{"questionId":"diag_compare_2","choice":"a"},{"questionId":"diag_add_1","choice":"b"},{"questionId":"diag_add_2","choice":"a"},{"questionId":"diag_conv_1","choice":"b"},{"questionId":"diag_conv_2","choice":"a"}]}'

# Fetch the next personalized lesson
curl -sS 'http://localhost:3000/api/lesson/next?sessionId=s_example'

# Request progress
curl -sS 'http://localhost:3000/api/progress?sessionId=s_example'

# Load the deterministic demo learner (idempotent reset)
curl -sS -X POST http://localhost:3000/api/demo/seed \
  -H 'Content-Type: application/json' -d '{}'
```

## Smoke test

With the server running, execute:

```bash
pnpm test:smoke
```

The script uses `curl` and `jq` to exercise session creation, diagnostic scoring (including wrong unlike-addition and conversion answers), lesson progression, five practice submissions, LLM fallback endpoints, progress, idempotent demo seeding, health, and CORS preflight.
