#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${BASE_URL:-http://localhost:3000}"
call() {
  local method="$1" path="$2" data="${3:-}"
  if [[ -n "$data" ]]; then
    curl -fsS -X "$method" "$BASE_URL$path" -H 'Content-Type: application/json' -d "$data"
  else
    curl -fsS -X "$method" "$BASE_URL$path"
  fi
}
show() { printf '\n%s\n' "$1"; jq . <<<"$2"; }

printf 'Adaptive Tutor API smoke test: %s\n' "$BASE_URL"
SESSION_JSON="$(call POST /api/session '{"name":"Smoke learner"}')"
SESSION_ID="$(jq -er '.sessionId' <<<"$SESSION_JSON")"
show 'POST /api/session' "$SESSION_JSON"

DIAGNOSTIC="$(call GET /api/diagnostic)"
jq -e '.questions as $questions | ($questions | length) == 8 and all($questions[]; has("correctOptionId") and has("hints") and has("feedbackCorrect") and all(.options[]; (has("misconceptionTag") | not)))' <<<"$DIAGNOSTIC" >/dev/null
show 'GET /api/diagnostic (8 questions, no option tags)' "$DIAGNOSTIC"

SUBMIT="$(jq -n --arg sessionId "$SESSION_ID" '{sessionId:$sessionId,answers:[{questionId:"diag_equiv_1",choice:"a"},{questionId:"diag_equiv_2",choice:"a"},{questionId:"diag_compare_1",choice:"a"},{questionId:"diag_compare_2",choice:"a"},{questionId:"diag_add_1",choice:"b"},{questionId:"diag_add_2",choice:"a"},{questionId:"diag_conv_1",choice:"b"},{questionId:"diag_conv_2",choice:"a"}]}')"
SUBMIT_RESPONSE="$(call POST /api/diagnostic/submit "$SUBMIT")"
jq -e '.mastery and .misconceptions.add_denominators == 1 and .misconceptions.conversion_error == 1 and .pathId == "visual" and (.reason | type == "string")' <<<"$SUBMIT_RESPONSE" >/dev/null
show 'POST /api/diagnostic/submit (wrong add + conversion)' "$SUBMIT_RESPONSE"

FIRST_LESSON="$(call GET "/api/lesson/next?sessionId=$SESSION_ID")"
FIRST_STEP_ID="$(jq -er '.step.id' <<<"$FIRST_LESSON")"
show 'GET /api/lesson/next' "$FIRST_LESSON"

PRACTICE_JSON=''
for attempt in $(seq 1 12); do
  CANDIDATE="$(call GET "/api/lesson/next?sessionId=$SESSION_ID")"
  if [[ "$(jq -r '.step.questionId // empty' <<<"$CANDIDATE")" != '' ]]; then PRACTICE_JSON="$CANDIDATE"; break; fi
done
if [[ -z "$PRACTICE_JSON" ]]; then echo 'Could not reach a practice step' >&2; exit 1; fi
QUESTION_ID="$(jq -er '.step.questionId' <<<"$PRACTICE_JSON")"
show 'GET /api/lesson/next (practice; answer withheld)' "$PRACTICE_JSON"
jq -e '(.step.question | has("prompt")) and ((.step.question.options | length) >= 2) and ((.step.question | has("correctOptionId")) | not)' <<<"$PRACTICE_JSON" >/dev/null

for index in $(seq 1 5); do
  if [[ "$index" -gt 1 ]]; then
    PRACTICE_JSON=''
    for attempt in $(seq 1 12); do
      CANDIDATE="$(call GET "/api/lesson/next?sessionId=$SESSION_ID")"
      if [[ "$(jq -r '.step.questionId // empty' <<<"$CANDIDATE")" != '' ]]; then PRACTICE_JSON="$CANDIDATE"; break; fi
    done
    QUESTION_ID="$(jq -er '.step.questionId' <<<"$PRACTICE_JSON")"
  fi
  CHOICE='b'
  if (( index % 2 == 0 )); then CHOICE='a'; fi
  ANSWER="$(jq -n --arg sessionId "$SESSION_ID" --arg questionId "$QUESTION_ID" --arg choice "$CHOICE" '{sessionId:$sessionId,questionId:$questionId,choice:$choice,timeMs:12000,hintsUsed:0}')"
  ANSWER_RESPONSE="$(call POST /api/answer "$ANSWER")"
  jq -e 'has("correct") and has("feedback") and has("mastery") and has("nextAction") and has("reason")' <<<"$ANSWER_RESPONSE" >/dev/null
  show "POST /api/answer ($index/5)" "$ANSWER_RESPONSE"
done

HINT="$(call POST /api/hint "$(jq -n --arg sessionId "$SESSION_ID" --arg questionId "$QUESTION_ID" '{sessionId:$sessionId,questionId:$questionId,level:1}')")"
jq -e 'has("hint") and (.source == "fallback" or .source == "llm")' <<<"$HINT" >/dev/null
show 'POST /api/hint' "$HINT"
EXPLAIN="$(call POST /api/explain "$(jq -n --arg sessionId "$SESSION_ID" --arg stepId "$FIRST_STEP_ID" '{sessionId:$sessionId,stepId:$stepId,style:"simpler"}')")"
jq -e 'has("explanation") and (.source == "fallback" or .source == "llm")' <<<"$EXPLAIN" >/dev/null
show 'POST /api/explain' "$EXPLAIN"
CHALLENGE="$(call POST /api/challenge "$(jq -n --arg sessionId "$SESSION_ID" --arg stepId "$FIRST_STEP_ID" '{sessionId:$sessionId,stepId:$stepId,message:"Can you explain why this is true?"}')")"
jq -e '(.verdict == "learner_correct" or .verdict == "content_correct" or .verdict == "unclear") and has("reply") and has("source")' <<<"$CHALLENGE" >/dev/null
show 'POST /api/challenge' "$CHALLENGE"
PROGRESS="$(call GET "/api/progress?sessionId=$SESSION_ID")"
jq -e 'has("mastery") and (.misconceptions | type == "array") and (.history | length == 5) and has("recommendation")' <<<"$PROGRESS" >/dev/null
show 'GET /api/progress' "$PROGRESS"
DEMO="$(call POST /api/demo/seed '{}')"
jq -e '.sessionId == "demo-learner" and .pathId == "visual" and .misconceptions.add_denominators == 2 and .misconceptions.conversion_error == 2' <<<"$DEMO" >/dev/null
show 'POST /api/demo/seed' "$DEMO"
DEMO_AGAIN="$(call POST /api/demo/seed '{}')"
jq -e '.sessionId == "demo-learner" and .pathId == "visual"' <<<"$DEMO_AGAIN" >/dev/null
HEALTH="$(call GET /api/health)"
jq -e '.status == "ok" and .storage == "in-memory" and (.llmConfigured | type == "boolean") and .sessions == 1 and (.uptimeSec | type == "number")' <<<"$HEALTH" >/dev/null
show 'GET /api/health' "$HEALTH"
PREFLIGHT="$(curl -sS -o /dev/null -w '%{http_code} %{header_json}' -X OPTIONS "$BASE_URL/api/session" -H 'Origin: https://example.com' -H 'Access-Control-Request-Method: POST')"
[[ "$PREFLIGHT" == 204* ]] || { echo "OPTIONS preflight failed: $PREFLIGHT" >&2; exit 1; }
printf '\nOPTIONS /api/session: %s\n' "$PREFLIGHT"
printf '\nPASS: all documented endpoint shapes and the fallback path were exercised.\n'
