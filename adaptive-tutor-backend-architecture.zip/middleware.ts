import { NextResponse, type NextRequest } from "next/server"

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
}

export function middleware(request: NextRequest) {
  if (request.method === "OPTIONS") {
    console.log(`[${new Date().toISOString()}] OPTIONS ${request.nextUrl.pathname}${request.nextUrl.search} 204 0ms source=deterministic body=-`)
    return new NextResponse(null, { status: 204, headers: corsHeaders })
  }
  const response = NextResponse.next()
  for (const [key, value] of Object.entries(corsHeaders)) response.headers.set(key, value)
  return response
}

export const config = { matcher: "/api/:path*" }
