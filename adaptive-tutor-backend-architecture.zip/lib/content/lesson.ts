import type { ExplanationStyle, LessonStep, MisconceptionTag, PathId, Question, SkillId } from "../types"

export const SKILL_NAMES: Record<SkillId, string> = {
  equivalence: "Equivalent fractions",
  comparing: "Comparing fractions",
  add_sub_unlike: "Adding and subtracting unlike fractions",
  conversion: "Mixed and improper fractions",
}

export const MISCONCEPTIONS: Record<MisconceptionTag, { label: string; remediation: string }> = {
  add_denominators: { label: "Adding denominators", remediation: "Use equal-sized fraction parts before combining numerators." },
  bigger_denominator_bigger_value: { label: "Bigger denominator means bigger value", remediation: "Compare fractions using equal-sized parts or a common denominator." },
  conversion_error: { label: "Mixed-number conversion error", remediation: "Multiply the whole number by the denominator, then add the numerator." },
  no_common_denominator: { label: "Missing a common denominator", remediation: "Rename both fractions with a shared denominator before operating." },
  multiply_only_numerator: { label: "Multiplying only the numerator", remediation: "Multiply both the numerator and denominator by the same factor." },
}

function question(
  id: string, skill: SkillId, difficulty: 1 | 2 | 3, prompt: string, correct: string,
  wrongs: Array<{ text: string; tag: MisconceptionTag }>, hints: [string, string, string],
): Question {
  const options = [
    { id: "a", text: correct },
    ...wrongs.map((wrong, index) => ({ id: index === 0 ? "b" : "c", text: wrong.text, misconceptionTag: wrong.tag })),
  ]
  return {
    id, skill, difficulty, prompt, options, correctOptionId: "a", hints,
    feedbackCorrect: "Correct. Your fraction reasoning is on track.",
    feedbackByMisconception: {
      add_denominators: "The denominator names the size of each part; it is not added to the other denominator.",
      bigger_denominator_bigger_value: "A larger denominator means smaller-sized parts, not automatically a larger fraction.",
      conversion_error: "For a mixed number, multiply the whole part by the denominator before adding the numerator.",
      no_common_denominator: "First rename both fractions with the same denominator.",
      multiply_only_numerator: "Equivalent fractions require multiplying the top and bottom by the same number.",
    },
  }
}

export const diagnosticQuestions: Question[] = [
  question("diag_equiv_1", "equivalence", 1, "Which fraction is equivalent to 2/3?", "4/6", [
    { text: "4/3", tag: "multiply_only_numerator" }, { text: "2/6", tag: "multiply_only_numerator" },
  ], ["Look for the same value written with different-sized parts.", "Multiply both 2 and 3 by the same whole number.", "Use a factor of 2 for both numerator and denominator."]),
  question("diag_equiv_2", "equivalence", 2, "Which fraction is equivalent to 3/5?", "9/15", [
    { text: "9/5", tag: "multiply_only_numerator" }, { text: "3/15", tag: "multiply_only_numerator" },
  ], ["Equivalent fractions keep the same value.", "Scale the numerator and denominator by one shared factor.", "Multiply both parts by 3."]),
  question("diag_compare_1", "comparing", 1, "Which fraction is greater: 3/4 or 2/3?", "3/4", [
    { text: "2/3", tag: "no_common_denominator" }, { text: "2/3 because 3 is the bigger denominator", tag: "bigger_denominator_bigger_value" },
  ], ["Compare the size of the pieces, not just the denominator.", "Rename both fractions with denominator 12.", "3/4 is 9/12 and 2/3 is 8/12."]),
  question("diag_compare_2", "comparing", 2, "Which fraction is greater: 5/8 or 2/3?", "2/3", [
    { text: "5/8", tag: "bigger_denominator_bigger_value" }, { text: "They are equal", tag: "no_common_denominator" },
  ], ["The denominators are different, so compare equivalent fractions.", "Use a shared denominator of 24.", "5/8 is 15/24 while 2/3 is 16/24."]),
  question("diag_add_1", "add_sub_unlike", 1, "What is 1/2 + 1/3?", "5/6", [
    { text: "2/5", tag: "add_denominators" }, { text: "2/6", tag: "no_common_denominator" },
  ], ["The two fractions have differently sized parts.", "Rename them as sixths before adding.", "1/2 is 3/6 and 1/3 is 2/6; add the numerators."]),
  question("diag_add_2", "add_sub_unlike", 2, "What is 3/4 - 1/6?", "7/12", [
    { text: "2/2", tag: "add_denominators" }, { text: "2/12", tag: "no_common_denominator" },
  ], ["Use a shared denominator before subtracting.", "Rename fourths and sixths as twelfths.", "3/4 is 9/12 and 1/6 is 2/12; subtract 2 from 9."]),
  question("diag_conv_1", "conversion", 1, "Convert 2 1/3 to an improper fraction.", "7/3", [
    { text: "3/3", tag: "conversion_error" }, { text: "2/4", tag: "conversion_error" },
  ], ["Think of how many thirds are in two wholes, then add one more third.", "Multiply the whole number by the denominator first.", "2 × 3 + 1 gives the numerator; keep denominator 3."]),
  question("diag_conv_2", "conversion", 2, "Convert 11/4 to a mixed number.", "2 3/4", [
    { text: "2 1/4", tag: "conversion_error" }, { text: "1 3/4", tag: "conversion_error" },
  ], ["How many groups of four fit into eleven?", "Divide 11 by 4 and keep the remainder over 4.", "11 = 2 × 4 + 3, so the result is 2 3/4."]),
]

const equivalenceSeeds = [
  [[1, 2, 2], [2, 3, 2], [3, 5, 2]],
  [[2, 5, 3], [3, 4, 2], [4, 7, 2]],
  [[5, 8, 3], [4, 9, 3], [7, 10, 2]],
] as const
const comparisonSeeds = [
  [[1, 2, 1, 3], [3, 4, 2, 3], [2, 5, 1, 3]],
  [[5, 8, 2, 3], [3, 7, 1, 2], [4, 9, 1, 2]],
  [[7, 10, 5, 8], [5, 12, 2, 5], [5, 9, 3, 5]],
] as const
const additionSeeds = [
  [[1, 2, 1, 4, "+"], [2, 3, 1, 6, "+"], [3, 4, 1, 8, "-"]],
  [[3, 5, 1, 2, "+"], [5, 6, 1, 4, "-"], [2, 7, 1, 3, "+"]],
  [[5, 8, 1, 3, "+"], [7, 9, 1, 6, "-"], [3, 10, 2, 5, "+"]],
] as const
const conversionSeeds = [
  [[1, 1, 2, "mixed"], [2, 1, 3, "mixed"], [7, 3, 0, "improper"]],
  [[3, 2, 5, "mixed"], [4, 3, 4, "mixed"], [13, 5, 0, "improper"]],
  [[5, 3, 7, "mixed"], [7, 5, 8, "mixed"], [23, 6, 0, "improper"]],
] as const

function simplify(n: number, d: number): string {
  const gcd = (a: number, b: number): number => b === 0 ? a : gcd(b, a % b)
  const divisor = gcd(Math.abs(n), d)
  return `${n / divisor}/${d / divisor}`
}
function makePracticeQuestion(skill: SkillId, difficulty: 1 | 2 | 3, index: number): Question {
  const id = `practice_${skill}_${difficulty}_${index + 1}`
  if (skill === "equivalence") {
    const [n, d, factor] = equivalenceSeeds[difficulty - 1][index]
    return question(id, skill, difficulty, `Which fraction is equivalent to ${n}/${d}?`, `${n * factor}/${d * factor}`, [
      { text: `${n * factor}/${d}`, tag: "multiply_only_numerator" },
      { text: `${n}/${d * factor}`, tag: "multiply_only_numerator" },
    ], ["Equivalent fractions have the same value.", "Use one factor for both numbers.", `Multiply both ${n} and ${d} by ${factor}.`])
  }
  if (skill === "comparing") {
    const [a, b, c, d] = comparisonSeeds[difficulty - 1][index]
    const leftIsGreater = a * d > c * b
    const correct = leftIsGreater ? `${a}/${b}` : `${c}/${d}`
    const other = leftIsGreater ? `${c}/${d}` : `${a}/${b}`
    const largerDenominatorFraction = b > d ? `${a}/${b}` : `${c}/${d}`
    const wrongTag: MisconceptionTag = largerDenominatorFraction === other ? "bigger_denominator_bigger_value" : "no_common_denominator"
    return question(id, skill, difficulty, `Which fraction is greater: ${a}/${b} or ${c}/${d}?`, correct, [
      { text: other, tag: wrongTag }, { text: "They are equal", tag: "no_common_denominator" },
    ], ["Compare their values rather than their denominators.", "Rename them using a common denominator.", `Cross-multiplication compares ${a} × ${d} with ${c} × ${b}.`])
  }
  if (skill === "add_sub_unlike") {
    const [a, b, c, d, operation] = additionSeeds[difficulty - 1][index]
    const denominator = b * d / argumentsGcd(b, d)
    const numerator = operation === "+" ? a * (denominator / b) + c * (denominator / d) : a * (denominator / b) - c * (denominator / d)
    const wrongNumerator = operation === "+" ? a + c : a - c
    return question(id, skill, difficulty, `What is ${a}/${b} ${operation} ${c}/${d}?`, simplify(numerator, denominator), [
      { text: simplify(wrongNumerator, b + d), tag: "add_denominators" },
      { text: simplify(wrongNumerator, denominator), tag: "no_common_denominator" },
    ], ["The pieces have different sizes, so rename them first.", `Use denominator ${denominator} for both fractions.`, `Rewrite each fraction with denominator ${denominator}, then ${operation === "+" ? "add" : "subtract"} the numerators.`])
  }
  const [first, second, third, kind] = conversionSeeds[difficulty - 1][index]
  if (kind === "mixed") {
    const numerator = first * third + second
    return question(id, skill, difficulty, `Convert ${first} ${second}/${third} to an improper fraction.`, `${numerator}/${third}`, [
      { text: `${first + second}/${third}`, tag: "conversion_error" },
      { text: `${numerator}/${third + 1}`, tag: "conversion_error" },
    ], ["Count the fraction-sized pieces in the whole part.", `Multiply ${first} by ${third}, then add ${second}.`, "Keep the denominator the same after finding the new numerator."])
  }
  const whole = Math.floor(first / second)
  const remainder = first % second
  return question(id, skill, difficulty, `Convert ${first}/${second} to a mixed number.`, `${whole} ${remainder}/${second}`, [
    { text: `${whole} ${first}/${second}`, tag: "conversion_error" },
    { text: `${whole - 1} ${remainder}/${second}`, tag: "conversion_error" },
  ], ["Divide the numerator by the denominator.", `The quotient is ${whole}; the remainder stays over ${second}.`, `Write ${first} as ${whole} groups of ${second} with ${remainder} left over.`])
}
function argumentsGcd(a: number, b: number): number { return b === 0 ? a : argumentsGcd(b, a % b) }

export const practiceQuestions: Question[] = ([1, 2, 3] as const).flatMap((difficulty) =>
  (["equivalence", "comparing", "add_sub_unlike", "conversion"] as const).flatMap((skill) =>
    [0, 1, 2].map((index) => makePracticeQuestion(skill, difficulty, index)),
  ),
)

const skillCopy: Record<SkillId, { symbolic: [string, string]; visual: [string, string]; model: [number, number] }> = {
  equivalence: {
    symbolic: ["Equivalent fractions name the same amount. Multiply or divide the numerator and denominator by the same nonzero number.", "For 2/3, multiplying top and bottom by 2 gives 4/6. The value stays the same because each third is split into two equal pieces."],
    visual: ["A fraction bar shows equivalent fractions by partitioning the same whole into more equal pieces without changing the shaded amount.", "Shade 2 of 3 equal parts. Split every part in two: now 4 of 6 smaller parts are shaded, so 2/3 = 4/6."],
    model: [6, 4],
  },
  comparing: {
    symbolic: ["To compare unlike fractions, rewrite them with a common denominator. Then compare their numerators because the pieces have equal size.", "Compare 3/4 and 2/3. Twelfths give 9/12 and 8/12, so 3/4 is greater."],
    visual: ["Fractions can be compared by partitioning equal-sized wholes into a shared number of parts and comparing the shaded lengths.", "A bar for 3/4 reaches 9 of 12 marks; a bar for 2/3 reaches 8 of 12. The 3/4 bar is longer."],
    model: [12, 9],
  },
  add_sub_unlike: {
    symbolic: ["For unlike denominators, first rename both fractions using a common denominator. Add or subtract only the numerators; keep the shared denominator.", "For 1/2 + 1/3, rename as 3/6 + 2/6. The sum is 5/6, not 2/5."],
    visual: ["Fraction bars can only be combined directly when their parts are the same size. Partition both wholes into a common set of pieces first.", "One half is 3 sixths and one third is 2 sixths. Combine five equal sixth-sized pieces to make 5/6."],
    model: [6, 5],
  },
  conversion: {
    symbolic: ["To convert a mixed number to an improper fraction, multiply the whole number by the denominator and add the numerator. Keep the denominator.", "For 2 1/3, two wholes contain 6 thirds; one more third makes 7/3. To reverse it, divide the numerator by the denominator."],
    visual: ["An improper fraction counts fraction-sized pieces across complete wholes and a leftover part. Group the pieces into whole bars.", "Seven thirds fill two whole bars (six thirds) with one third remaining, so 7/3 = 2 1/3."],
    model: [3, 2],
  },
}

const skillOrder: SkillId[] = ["equivalence", "comparing", "add_sub_unlike", "conversion"]
export const learningPaths: Record<PathId, Record<SkillId, LessonStep[]>> = { symbolic: {} as Record<SkillId, LessonStep[]>, visual: {} as Record<SkillId, LessonStep[]> }
export const reteachSteps: Record<PathId, Record<SkillId, LessonStep>> = { symbolic: {} as Record<SkillId, LessonStep>, visual: {} as Record<SkillId, LessonStep> }
export const staticFallbacks: Record<string, Record<ExplanationStyle, string>> = {}

for (const pathId of ["symbolic", "visual"] as const) {
  for (const skill of skillOrder) {
    const copy = skillCopy[skill]
    const useVisual = pathId === "visual"
    const idBase = `${pathId}-${skill}`
    const visual = useVisual ? { type: "bar" as const, parts: copy.model[0], shaded: copy.model[1] } : undefined
    const steps: LessonStep[] = [
      { id: `${idBase}-explanation`, type: "explanation", skill, title: `${SKILL_NAMES[skill]}: the idea`, body: useVisual ? copy.visual[0] : copy.symbolic[0], ...(visual ? { visual } : {}) },
      { id: `${idBase}-example`, type: "example", skill, title: `${SKILL_NAMES[skill]}: worked example`, body: useVisual ? copy.visual[1] : copy.symbolic[1], ...(visual ? { visual } : {}) },
      { id: `${idBase}-practice`, type: "practice", skill, title: `Practice ${SKILL_NAMES[skill]}`, body: "Try the question, then use the feedback to decide what to practice next." },
    ]
    learningPaths[pathId][skill] = steps
    const reteach: LessonStep = {
      id: `${idBase}-reteach`, type: "explanation", skill, title: `Let's revisit ${SKILL_NAMES[skill]}`,
      body: useVisual ? `Reteach: ${copy.visual[0]} ${copy.visual[1]}` : `Reteach: ${copy.symbolic[0]} ${copy.symbolic[1]}`,
      ...(visual ? { visual } : {}),
    }
    reteachSteps[pathId][skill] = reteach
    staticFallbacks[steps[0].id] = {
      simpler: `In short: ${useVisual ? copy.visual[0] : copy.symbolic[0]}`,
      visual: copy.visual[0],
      example: useVisual ? copy.visual[1] : copy.symbolic[1],
    }
    staticFallbacks[steps[1].id] = {
      simpler: useVisual ? copy.visual[1] : copy.symbolic[1],
      visual: copy.visual[1],
      example: useVisual ? copy.visual[1] : copy.symbolic[1],
    }
    staticFallbacks[steps[2].id] = {
      simpler: `Try one ${SKILL_NAMES[skill]} problem at a time, and show the equivalent parts before calculating.`,
      visual: `Sketch equal-sized fraction bars, then compare or combine the shaded parts.`,
      example: useVisual ? copy.visual[1] : copy.symbolic[1],
    }
    staticFallbacks[reteach.id] = {
      simpler: useVisual ? copy.visual[0] : copy.symbolic[0],
      visual: copy.visual[0],
      example: useVisual ? copy.visual[1] : copy.symbolic[1],
    }
  }
}

export const allLessonSteps: LessonStep[] = [
  ...(["symbolic", "visual"] as const).flatMap((pathId) => skillOrder.flatMap((skill) => [
    ...learningPaths[pathId][skill], reteachSteps[pathId][skill],
  ])),
]
export function findStep(stepId: string): LessonStep | undefined {
  return allLessonSteps.find((step) => step.id === stepId)
}
export function getQuestion(questionId: string): Question | undefined {
  return diagnosticQuestions.find((item) => item.id === questionId) ?? practiceQuestions.find((item) => item.id === questionId)
}
export function publicDiagnosticQuestions(): Array<Omit<Question, "feedbackByMisconception"> & { options: Array<{ id: string; text: string }> }> {
  return diagnosticQuestions.map(({ options, ...item }) => ({
    ...item,
    options: options.map(({ id, text }) => ({ id, text })),
  }))
}
