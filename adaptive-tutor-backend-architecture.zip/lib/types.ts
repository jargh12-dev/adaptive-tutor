import { z } from "zod"

export const SKILLS = ["equivalence", "comparing", "add_sub_unlike", "conversion"] as const
export type SkillId = (typeof SKILLS)[number]
export const MISCONCEPTION_TAGS = [
  "add_denominators",
  "bigger_denominator_bigger_value",
  "conversion_error",
  "no_common_denominator",
  "multiply_only_numerator",
] as const
export type MisconceptionTag = (typeof MISCONCEPTION_TAGS)[number]
export type PathId = "symbolic" | "visual"
export type ExplanationStyle = "simpler" | "visual" | "example"
export type StepType = "explanation" | "example" | "practice"

export type Option = { id: string; text: string; misconceptionTag?: MisconceptionTag }
export type Question = {
  id: string
  skill: SkillId
  difficulty: 1 | 2 | 3
  prompt: string
  options: Option[]
  correctOptionId: string
  hints: [string, string, string]
  feedbackCorrect: string
  feedbackByMisconception: Partial<Record<MisconceptionTag, string>>
}
export type PublicQuestion = Omit<Question, "correctOptionId" | "feedbackByMisconception"> & {
  options: Array<Omit<Option, "misconceptionTag">>
}
export type VisualModel = { type: "bar" | "area"; parts: number; shaded: number }
export type LessonStep = {
  id: string
  type: StepType
  skill: SkillId
  title: string
  body: string
  visual?: VisualModel
  questionId?: string
}
export type Attempt = {
  attemptId: string
  sessionId: string
  questionId: string
  skill: SkillId
  choice: string
  correct: boolean
  timeMs: number
  hintsUsed: number
  misconceptionTag?: MisconceptionTag
  masteryAfter: number
  createdAt: string
}
export type Challenge = {
  challengeId: string
  stepId: string
  message: string
  verdict: "learner_correct" | "content_correct" | "unclear"
  reply: string
  createdAt: string
}
export type Session = {
  sessionId: string
  name?: string
  mastery: Record<SkillId, number>
  misconceptions: Partial<Record<MisconceptionTag, number>>
  pathMisconceptions: Record<PathId, Partial<Record<MisconceptionTag, number>>>
  pathId: PathId | null
  difficulty: 1 | 2 | 3
  streak: number
  correctStreak: number
  wrongStreak: number
  cursor: number
  diagnosticCompleted: boolean
  answersOnPath: number
  completedStepIds: string[]
  answeredQuestionIds: string[]
  questionStepMap: Record<string, string>
  reteachPending: Partial<Record<SkillId, boolean>>
  history: Attempt[]
  challenges: Challenge[]
  createdAt: string
}

export const sessionSchema = z.object({ name: z.string().trim().max(80).optional() }).strict()
export const diagnosticSubmitSchema = z.object({
  sessionId: z.string().min(1),
  answers: z.array(z.object({ questionId: z.string().min(1), choice: z.string().min(1) }).strict()).min(1).max(8),
}).strict()
export const answerSchema = z.object({
  sessionId: z.string().min(1), questionId: z.string().min(1), choice: z.string().min(1),
  timeMs: z.number().int().min(0).max(600_000), hintsUsed: z.number().int().min(0).max(3),
}).strict()
export const explainSchema = z.object({ sessionId: z.string().min(1), stepId: z.string().min(1), style: z.enum(["simpler", "visual", "example"]) }).strict()
export const hintSchema = z.object({ sessionId: z.string().min(1), questionId: z.string().min(1), level: z.number().int().min(1).max(3) }).strict()
export const challengeSchema = z.object({ sessionId: z.string().min(1), stepId: z.string().min(1), message: z.string().trim().min(1).max(1000) }).strict()
export const sessionIdQuerySchema = z.object({ sessionId: z.string().min(1) }).strict()
export const emptyQuerySchema = z.object({}).strict()
