import type { PathId, Session, SkillId } from "../types"

export type PathDecision = { pathId: PathId; reason: string }

export function selectPath(mastery: Record<SkillId, number>, misconceptions: Partial<Record<string, number>>): PathDecision {
  const denominatorMisconceptions = misconceptions.add_denominators ?? 0
  const conversionMisconceptions = misconceptions.conversion_error ?? 0
  if (denominatorMisconceptions + conversionMisconceptions >= 2) {
    const tags = [
      ...(denominatorMisconceptions ? ["adding denominators"] : []),
      ...(conversionMisconceptions ? ["mixed-number conversion"] : []),
    ]
    return {
      pathId: "visual",
      reason: `A visual path is a good fit because the diagnostic showed ${tags.join(" and ")} misconceptions.`,
    }
  }
  const average = Object.values(mastery).reduce((sum, value) => sum + value, 0) / Object.keys(mastery).length
  if (average >= 0.7) return { pathId: "symbolic", reason: "Your diagnostic average is strong, so we will start with a concise symbolic path." }
  return { pathId: "symbolic", reason: "We will start with the symbolic path and adjust it as your practice shows what helps." }
}

export function shouldSwitchPath(session: Session, tag?: string): boolean {
  if (!session.pathId || !tag || session.answersOnPath < 3) return false
  return (session.pathMisconceptions[session.pathId][tag as keyof typeof session.pathMisconceptions.symbolic] ?? 0) >= 2
}

export function alternatePath(path: PathId): PathId {
  return path === "symbolic" ? "visual" : "symbolic"
}
