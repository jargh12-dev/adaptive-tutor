import type { MisconceptionTag, Option } from "../types"

export const MISCONCEPTION_LABELS: Record<MisconceptionTag, string> = {
  add_denominators: "Adding denominators",
  bigger_denominator_bigger_value: "Bigger denominator means bigger value",
  conversion_error: "Mixed-number conversion error",
  no_common_denominator: "Missing a common denominator",
  multiply_only_numerator: "Multiplying only the numerator",
}

export const MISCONCEPTION_REMEDIATION: Record<MisconceptionTag, string> = {
  add_denominators: "Use equal-sized fraction parts before combining the numerators.",
  bigger_denominator_bigger_value: "Compare fractions using equal-sized parts or a common denominator.",
  conversion_error: "Multiply the whole number by the denominator, then add the numerator.",
  no_common_denominator: "Rename both fractions with a shared denominator before operating.",
  multiply_only_numerator: "Multiply both the numerator and denominator by the same factor.",
}

export function misconceptionForChoice(options: Option[], choice: string, correctOptionId: string): MisconceptionTag | undefined {
  if (choice === correctOptionId) return undefined
  return options.find((option) => option.id === choice)?.misconceptionTag
}

export function labelForMisconception(tag: MisconceptionTag): string {
  return MISCONCEPTION_LABELS[tag]
}
