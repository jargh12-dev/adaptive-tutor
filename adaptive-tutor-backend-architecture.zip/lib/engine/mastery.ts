import type { SkillId } from "../types"

export function updateMastery(oldValue: number, correct: boolean, hintsUsed: number, timeMs: number): number {
  const target = correct ? Math.min(timeMs > 30_000 ? 0.8 : 1, Math.max(0.5, 1 - 0.15 * hintsUsed)) : 0
  const next = Math.max(0, Math.min(1, oldValue + 0.3 * (target - oldValue)))
  return Math.round(next * 100) / 100
}

export function updateSkillMastery(masteries: Record<SkillId, number>, skill: SkillId, correct: boolean, hintsUsed: number, timeMs: number): Record<SkillId, number> {
  return { ...masteries, [skill]: updateMastery(masteries[skill], correct, hintsUsed, timeMs) }
}
