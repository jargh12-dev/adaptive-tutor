export type DifficultySignal = "level_up" | "reteach" | null
export type DifficultyUpdate = { difficulty: 1 | 2 | 3; signal: DifficultySignal }

export function updateDifficulty(current: 1 | 2 | 3, correctStreak: number, wrongStreak: number): DifficultyUpdate {
  if (correctStreak >= 3) return { difficulty: Math.min(3, current + 1) as 1 | 2 | 3, signal: "level_up" }
  if (wrongStreak >= 2) return { difficulty: Math.max(1, current - 1) as 1 | 2 | 3, signal: "reteach" }
  return { difficulty: current, signal: null }
}
