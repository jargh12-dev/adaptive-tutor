import type { ExplanationStyle, LessonStep, Question } from "../types"

const jsonOnly = "Use ONLY the reviewed content below. Do not add, infer, or invent mathematical facts. Keep the response to at most 4 sentences. Return strict JSON only, with no markdown or extra keys."
export function explainPrompt(step: LessonStep, style: ExplanationStyle): string {
  return `${jsonOnly} Produce {"explanation":"..."}. Requested style: ${style}. Reviewed step JSON: ${JSON.stringify(step)}`
}
export function hintPrompt(question: Question, level: 1 | 2 | 3): string {
  const levelRule = level < 3 ? "Do not reveal the answer or state the final result." : "A final hint may name the operation to perform, but should still guide rather than simply state the correct option."
  return `${jsonOnly} ${levelRule} Produce {"hint":"..."}. Requested hint level: ${level}. Reviewed question JSON: ${JSON.stringify(question)}`
}
export function challengePrompt(step: LessonStep, message: string): string {
  return `${jsonOnly} Judge the learner's challenge only against this reviewed step. Use verdict learner_correct if the learner points out an error in the reviewed content, content_correct if the content is correct, and unclear if evidence is insufficient. Produce {"verdict":"learner_correct"|"content_correct"|"unclear","reply":"..."}. Reviewed step JSON: ${JSON.stringify(step)} Learner message: ${JSON.stringify(message)}`
}
