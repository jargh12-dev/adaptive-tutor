import Anthropic from "@anthropic-ai/sdk"
import { z, type ZodType } from "zod"

export type LlmSource = "llm" | "fallback"
export type LlmResult<T> = { data: T; source: LlmSource }

export const explanationOutputSchema = z.object({ explanation: z.string().trim().min(1).max(2000) }).strict()
export const hintOutputSchema = z.object({ hint: z.string().trim().min(1).max(1000) }).strict()
export const challengeOutputSchema = z.object({
  verdict: z.enum(["learner_correct", "content_correct", "unclear"]),
  reply: z.string().trim().min(1).max(1000),
}).strict()

export function isLlmConfigured(): boolean {
  return Boolean(process.env.ANTHROPIC_API_KEY?.trim())
}

export async function generateJson<T>(prompt: string, schema: ZodType<T>, fallback: T): Promise<LlmResult<T>> {
  const apiKey = process.env.ANTHROPIC_API_KEY?.trim()
  if (!apiKey) {
    console.info("[llm] fallback: ANTHROPIC_API_KEY is not configured")
    return { data: fallback, source: "fallback" }
  }
  const client = new Anthropic({ apiKey, maxRetries: 0, timeout: 8_000 })
  const model = process.env.ANTHROPIC_MODEL?.trim() || "claude-sonnet-5-5"
  let lastReason = "invalid output"
  for (let attempt = 1; attempt <= 2; attempt += 1) {
    const controller = new AbortController()
    const timeout = setTimeout(() => controller.abort(), 8_000)
    try {
      const response = await client.messages.create({
        model,
        max_tokens: 450,
        system: prompt,
        messages: [{ role: "user", content: "Return the requested JSON object." }],
      }, { signal: controller.signal })
      const text = response.content.find((block) => block.type === "text")?.text
      if (!text) throw new Error("empty response")
      const parsedJson: unknown = JSON.parse(text)
      const parsed = schema.safeParse(parsedJson)
      if (!parsed.success) throw new Error("response did not match schema")
      return { data: parsed.data, source: "llm" }
    } catch (error) {
      lastReason = controller.signal.aborted ? "8s timeout" : error instanceof Error ? error.message : "unknown error"
      if (attempt === 1) continue
    } finally {
      clearTimeout(timeout)
    }
  }
  console.warn(`[llm] fallback: request failed after retry (${lastReason})`)
  return { data: fallback, source: "fallback" }
}
