import { ZodError, type ZodType } from "zod"

export type ApiSource = "deterministic" | "llm" | "fallback"
export type ApiResult<T = unknown> = { data: T; source: ApiSource; status?: number }
export type ApiContext = { request: Request; body: unknown; url: URL }
export type ApiHandler = (context: ApiContext) => Promise<ApiResult> | ApiResult

const routeBanner = globalThis as typeof globalThis & { __adaptiveTutorBanner?: boolean }
if (!routeBanner.__adaptiveTutorBanner) {
  routeBanner.__adaptiveTutorBanner = true
  console.info(`[startup] routes=/api/session,/api/diagnostic,/api/diagnostic/submit,/api/lesson/next,/api/answer,/api/progress,/api/explain,/api/hint,/api/challenge,/api/health,/api/demo/seed llmConfigured=${Boolean(process.env.ANTHROPIC_API_KEY?.trim())}`)
}

export class UnknownSessionError extends Error {
  constructor() { super("Unknown session"); this.name = "UnknownSessionError" }
}
export class ApiError extends Error {
  constructor(message: string, readonly status = 400, readonly details?: unknown) { super(message); this.name = "ApiError" }
}

export function parseInput<T>(schema: ZodType<T>, input: unknown): T {
  const result = schema.safeParse(input)
  if (!result.success) throw new ApiError("Validation failed", 400, result.error.issues)
  return result.data
}

export function requireSession<T extends { sessionId: string }>(session: T | undefined): T {
  if (!session) throw new UnknownSessionError()
  return session
}

export function withApi(handler: ApiHandler) {
  return async (request: Request): Promise<Response> => {
    const started = performance.now()
    const url = new URL(request.url)
    let body: unknown = {}
    let status = 200
    let source: ApiSource = "deterministic"
    try {
      if (request.method !== "GET" && request.method !== "HEAD") {
        const text = await request.text()
        if (text.trim()) {
          try { body = JSON.parse(text) }
          catch { throw new ApiError("Invalid JSON request body", 400) }
        }
      }
      const result = await handler({ request, body, url })
      source = result.source
      status = result.status ?? 200
      return Response.json(result.data, { status })
    } catch (error) {
      let payload: { error: string; details?: unknown }
      if (error instanceof UnknownSessionError) {
        status = 404
        payload = { error: error.message }
      } else if (error instanceof ApiError) {
        status = error.status
        payload = { error: error.message, ...(error.details === undefined ? {} : { details: error.details }) }
      } else if (error instanceof ZodError) {
        status = 400
        payload = { error: "Validation failed", details: error.issues }
      } else {
        status = 500
        payload = { error: "Unexpected server error" }
        console.error("[api] unexpected error", error)
      }
      return Response.json(payload, { status })
    } finally {
      const elapsed = Math.round(performance.now() - started)
      let bodyText = "-"
      if (body !== null && typeof body === "object" && Object.keys(body).length > 0) {
        try { bodyText = JSON.stringify(body).slice(0, 500) }
        catch { bodyText = "[unserializable]" }
      }
      console.log(`[${new Date().toISOString()}] ${request.method} ${url.pathname}${url.search} ${status} ${elapsed}ms source=${source} body=${bodyText}`)
    }
  }
}

export function result(data: unknown, source: ApiSource = "deterministic", status?: number): ApiResult {
  return { data, source, ...(status === undefined ? {} : { status }) }
}
