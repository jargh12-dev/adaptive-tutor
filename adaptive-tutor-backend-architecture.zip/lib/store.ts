import { randomUUID } from "node:crypto"
import type { Attempt, Challenge, MisconceptionTag, PathId, Session, SkillId } from "./types"

const initialMastery = (): Record<SkillId, number> => ({
  equivalence: 0.3,
  comparing: 0.3,
  add_sub_unlike: 0.3,
  conversion: 0.3,
})

const createInitialState = () => ({
  sessions: new Map<string, Session>(),
  attempts: [] as Attempt[],
  mastery: new Map<string, Record<SkillId, number>>(),
  misconceptions: new Map<string, Partial<Record<MisconceptionTag, number>>>(),
  histories: new Map<string, Attempt[]>(),
  challenges: new Map<string, Challenge[]>(),
})

type StoreState = ReturnType<typeof createInitialState>
const globalStore = globalThis as typeof globalThis & { __adaptiveTutorStore?: StoreState }
const store = (globalStore.__adaptiveTutorStore ??= createInitialState())

export function createSession(name?: string, sessionId = `s_${randomUUID().replaceAll("-", "").slice(0, 12)}`): Session {
  const session: Session = {
    sessionId,
    ...(name ? { name } : {}),
    mastery: initialMastery(),
    misconceptions: {},
    pathMisconceptions: { symbolic: {}, visual: {} },
    pathId: null,
    difficulty: 1,
    streak: 0,
    correctStreak: 0,
    wrongStreak: 0,
    cursor: 0,
    diagnosticCompleted: false,
    answersOnPath: 0,
    completedStepIds: [],
    answeredQuestionIds: [],
    questionStepMap: {},
    reteachPending: {},
    history: [],
    challenges: [],
    createdAt: new Date().toISOString(),
  }
  saveSession(session)
  return session
}

export function getSession(sessionId: string): Session | undefined {
  return store.sessions.get(sessionId)
}
export function saveSession(session: Session): void {
  store.sessions.set(session.sessionId, session)
  store.mastery.set(session.sessionId, session.mastery)
  store.misconceptions.set(session.sessionId, session.misconceptions)
  store.histories.set(session.sessionId, session.history)
  store.challenges.set(session.sessionId, session.challenges)
}
export function addAttempt(attempt: Attempt): void {
  store.attempts.push(attempt)
  const session = getSession(attempt.sessionId)
  if (session) {
    session.history.push(attempt)
    session.answeredQuestionIds.push(attempt.questionId)
    saveSession(session)
  }
}
export function addChallenge(sessionId: string, challenge: Challenge): void {
  const session = getSession(sessionId)
  if (!session) return
  session.challenges.push(challenge)
  saveSession(session)
}
export function getHistory(sessionId: string): Attempt[] {
  return store.histories.get(sessionId) ?? []
}
export function getChallenges(sessionId: string): Challenge[] {
  return store.challenges.get(sessionId) ?? []
}
export function getSessionCount(): number {
  return store.sessions.size
}
export function getAllAttempts(): Attempt[] {
  return store.attempts
}
export function resetStore(): void {
  store.sessions.clear()
  store.attempts.length = 0
  store.mastery.clear()
  store.misconceptions.clear()
  store.histories.clear()
  store.challenges.clear()
}
export function setInitialMastery(session: Session, mastery: Record<SkillId, number>): void {
  session.mastery = mastery
  saveSession(session)
}
export function incrementMisconception(session: Session, tag: MisconceptionTag, pathScoped = true): number {
  session.misconceptions[tag] = (session.misconceptions[tag] ?? 0) + 1
  if (pathScoped && session.pathId) {
    const currentPath: PathId = session.pathId
    session.pathMisconceptions[currentPath][tag] = (session.pathMisconceptions[currentPath][tag] ?? 0) + 1
  }
  saveSession(session)
  return session.misconceptions[tag]
}
export function replaceDemoSession(session: Session): void {
  resetStore()
  saveSession(session)
}
