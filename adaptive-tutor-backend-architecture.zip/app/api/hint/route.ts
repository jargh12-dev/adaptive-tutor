import { getQuestion } from "@/lib/content/lesson"
import { hintOutputSchema, generateJson } from "@/lib/llm/client"
import { hintPrompt } from "@/lib/llm/prompts"
import { ApiError, parseInput, requireSession, result, withApi } from "@/lib/http"
import { getSession } from "@/lib/store"
import { hintSchema } from "@/lib/types"

export const POST = withApi(async ({ body }) => {
  const input = parseInput(hintSchema, body)
  requireSession(getSession(input.sessionId))
  const question = getQuestion(input.questionId)
  if (!question) throw new ApiError("Unknown question")
  const fallback = question.hints[input.level - 1] ?? question.hints[0]
  const generated = await generateJson(hintPrompt(question, input.level as 1 | 2 | 3), hintOutputSchema, { hint: fallback })
  return result({ hint: generated.data.hint, source: generated.source }, generated.source)
})
