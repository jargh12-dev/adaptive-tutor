import { findStep } from "@/lib/content/lesson"
import { challengeOutputSchema, generateJson } from "@/lib/llm/client"
import { challengePrompt } from "@/lib/llm/prompts"
import { ApiError, parseInput, requireSession, result, withApi } from "@/lib/http"
import { addChallenge, getSession } from "@/lib/store"
import { challengeSchema } from "@/lib/types"
import { randomUUID } from "node:crypto"

export const POST = withApi(async ({ body }) => {
  const input = parseInput(challengeSchema, body)
  requireSession(getSession(input.sessionId))
  const step = findStep(input.stepId)
  if (!step) throw new ApiError("Unknown lesson step")
  const generated = await generateJson(challengePrompt(step, input.message), challengeOutputSchema, {
    verdict: "unclear" as const,
    reply: "Let's recheck this step together.",
  })
  addChallenge(input.sessionId, {
    challengeId: `c_${randomUUID().replaceAll("-", "").slice(0, 12)}`,
    stepId: input.stepId,
    message: input.message,
    verdict: generated.data.verdict,
    reply: generated.data.reply,
    createdAt: new Date().toISOString(),
  })
  return result({ verdict: generated.data.verdict, reply: generated.data.reply, source: generated.source }, generated.source)
})
