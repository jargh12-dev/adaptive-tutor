import { isLlmConfigured } from "@/lib/llm/client"
import { getSessionCount } from "@/lib/store"
import { emptyQuerySchema } from "@/lib/types"
import { parseInput, result, withApi } from "@/lib/http"

const startedAt = Date.now()
export const GET = withApi(({ url }) => {
  parseInput(emptyQuerySchema, Object.fromEntries(url.searchParams))
  return result({
    status: "ok",
    storage: "in-memory",
    llmConfigured: isLlmConfigured(),
    sessions: getSessionCount(),
    uptimeSec: Math.floor((Date.now() - startedAt) / 1000),
  })
})
