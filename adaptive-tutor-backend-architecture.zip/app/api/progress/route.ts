import { MISCONCEPTIONS, SKILL_NAMES } from "@/lib/content/lesson"
import { parseInput, requireSession, result, withApi } from "@/lib/http"
import { getHistory, getSession } from "@/lib/store"
import { sessionIdQuerySchema, type SkillId } from "@/lib/types"

export const GET = withApi(({ url }) => {
  const { sessionId } = parseInput(sessionIdQuerySchema, Object.fromEntries(url.searchParams))
  const session = requireSession(getSession(sessionId))
  const weakest = (Object.entries(session.mastery) as Array<[SkillId, number]>).sort((a, b) => a[1] - b[1])[0]
  const recommendation = !session.diagnosticCompleted
    ? "Complete the diagnostic to find the best starting point."
    : weakest
      ? `Keep practicing ${SKILL_NAMES[weakest[0]]}; it is currently your lowest mastery area.`
      : "Continue with your next lesson."
  const misconceptions = Object.entries(session.misconceptions).map(([tag, count]) => ({
    tag,
    label: MISCONCEPTIONS[tag as keyof typeof MISCONCEPTIONS].label,
    count: count ?? 0,
  }))
  return result({ mastery: session.mastery, misconceptions, history: getHistory(sessionId), recommendation })
})
