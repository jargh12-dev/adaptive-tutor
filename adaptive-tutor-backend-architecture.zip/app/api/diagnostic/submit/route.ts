import { diagnosticQuestions } from "@/lib/content/lesson"
import { selectPath } from "@/lib/engine/pathSelector"
import { ApiError, parseInput, requireSession, result, withApi } from "@/lib/http"
import { getSession, saveSession } from "@/lib/store"
import { diagnosticSubmitSchema, type SkillId } from "@/lib/types"

export const POST = withApi(({ body }) => {
  const input = parseInput(diagnosticSubmitSchema, body)
  const session = requireSession(getSession(input.sessionId))
  const submitted = new Map<string, string>()
  for (const answer of input.answers) {
    if (submitted.has(answer.questionId)) throw new ApiError(`Duplicate answer for ${answer.questionId}`)
    submitted.set(answer.questionId, answer.choice)
  }
  for (const [questionId, choice] of submitted) {
    const question = diagnosticQuestions.find((item) => item.id === questionId)
    if (!question) throw new ApiError(`Unknown diagnostic question: ${questionId}`)
    if (!question.options.some((option) => option.id === choice)) throw new ApiError(`Unknown choice ${choice} for ${questionId}`)
  }
  const correctBySkill: Record<SkillId, number> = { equivalence: 0, comparing: 0, add_sub_unlike: 0, conversion: 0 }
  for (const question of diagnosticQuestions) {
    const choice = submitted.get(question.id)
    if (choice === question.correctOptionId) correctBySkill[question.skill] += 1
    else if (choice) {
      const tag = question.options.find((option) => option.id === choice)?.misconceptionTag
      if (tag) session.misconceptions[tag] = (session.misconceptions[tag] ?? 0) + 1
    }
  }
  session.mastery = {
    equivalence: Math.round(correctBySkill.equivalence / 2 * 100) / 100,
    comparing: Math.round(correctBySkill.comparing / 2 * 100) / 100,
    add_sub_unlike: Math.round(correctBySkill.add_sub_unlike / 2 * 100) / 100,
    conversion: Math.round(correctBySkill.conversion / 2 * 100) / 100,
  }
  const decision = selectPath(session.mastery, session.misconceptions)
  session.pathId = decision.pathId
  session.diagnosticCompleted = true
  session.answersOnPath = 0
  saveSession(session)
  return result({ mastery: session.mastery, misconceptions: session.misconceptions, pathId: session.pathId, reason: decision.reason })
})
