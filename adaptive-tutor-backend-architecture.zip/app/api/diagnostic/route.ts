import { diagnosticQuestions, publicDiagnosticQuestions } from "@/lib/content/lesson"
import { parseInput, result, withApi } from "@/lib/http"
import { emptyQuerySchema } from "@/lib/types"

export const GET = withApi(({ url }) => {
  parseInput(emptyQuerySchema, Object.fromEntries(url.searchParams))
  return result({ questions: publicDiagnosticQuestions() })
})
