import { addAttempt, createSession, resetStore, saveSession } from "@/lib/store"
import { parseInput, result, withApi } from "@/lib/http"
import { emptyQuerySchema, type Attempt } from "@/lib/types"

export const POST = withApi(({ body }) => {
  parseInput(emptyQuerySchema, body)
  resetStore()
  const session = createSession("Demo learner", "demo-learner")
  session.mastery = { equivalence: 0.52, comparing: 0.48, add_sub_unlike: 0.12, conversion: 0.18 }
  session.misconceptions = { add_denominators: 2, conversion_error: 2 }
  session.pathMisconceptions.visual = { add_denominators: 2, conversion_error: 2 }
  session.pathId = "visual"
  session.diagnosticCompleted = true
  session.answersOnPath = 2
  const history: Attempt[] = [
    { attemptId: "demo-attempt-1", sessionId: session.sessionId, questionId: "practice_add_sub_unlike_1_1", skill: "add_sub_unlike", choice: "b", correct: false, timeMs: 18_000, hintsUsed: 1, misconceptionTag: "add_denominators", masteryAfter: 0.12, createdAt: new Date(Date.now() - 120_000).toISOString() },
    { attemptId: "demo-attempt-2", sessionId: session.sessionId, questionId: "practice_conversion_1_2", skill: "conversion", choice: "b", correct: false, timeMs: 22_000, hintsUsed: 0, misconceptionTag: "conversion_error", masteryAfter: 0.18, createdAt: new Date(Date.now() - 60_000).toISOString() },
  ]
  saveSession(session)
  for (const attempt of history) addAttempt(attempt)
  saveSession(session)
  return result({ sessionId: session.sessionId, mastery: session.mastery, misconceptions: session.misconceptions, pathId: session.pathId })
})
