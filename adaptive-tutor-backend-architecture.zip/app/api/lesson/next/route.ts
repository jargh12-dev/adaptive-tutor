import { learningPaths, practiceQuestions, reteachSteps } from "@/lib/content/lesson"
import { ApiError, parseInput, requireSession, result, withApi } from "@/lib/http"
import { getSession, saveSession } from "@/lib/store"
import { sessionIdQuerySchema, type LessonStep, type SkillId } from "@/lib/types"

const skillOrder: SkillId[] = ["equivalence", "comparing", "add_sub_unlike", "conversion"]

export const GET = withApi(({ url }) => {
  const { sessionId } = parseInput(sessionIdQuerySchema, Object.fromEntries(url.searchParams))
  const session = requireSession(getSession(sessionId))
  if (!session.diagnosticCompleted || !session.pathId) throw new ApiError("Complete the diagnostic before requesting a lesson.", 409)

  const orderedSkills = [...skillOrder].sort((a, b) => session.mastery[a] - session.mastery[b] || skillOrder.indexOf(a) - skillOrder.indexOf(b))
  const reteachSkill = orderedSkills.find((skill) => session.reteachPending[skill])
  let step: LessonStep | undefined
  if (reteachSkill) {
    step = reteachSteps[session.pathId][reteachSkill]
    session.reteachPending[reteachSkill] = false
  } else {
    for (const skill of orderedSkills) {
      const candidate = learningPaths[session.pathId][skill].find((item) => !session.completedStepIds.includes(item.id))
      if (candidate) { step = candidate; break }
    }
  }
  if (!step) {
    for (const skill of orderedSkills) {
      const question = practiceQuestions.find((item) => item.skill === skill && item.difficulty === session.difficulty && !session.answeredQuestionIds.includes(item.id))
        ?? practiceQuestions.find((item) => item.skill === skill && !session.answeredQuestionIds.includes(item.id))
      if (question) {
        step = learningPaths[session.pathId][skill].find((item) => item.type === "practice")
        if (step) step = { ...step, title: `More practice: ${step.title}` }
        break
      }
    }
  }
  if (!step) throw new ApiError("No unanswered practice questions remain for this session.", 409)

  let responseStep: Record<string, unknown> = { ...step }
  if (step.type === "practice") {
    const question = practiceQuestions.find((item) => item.skill === step!.skill && item.difficulty === session.difficulty && !session.answeredQuestionIds.includes(item.id))
      ?? practiceQuestions.find((item) => item.skill === step!.skill && !session.answeredQuestionIds.includes(item.id))
    if (!question) throw new ApiError("No unanswered practice questions remain for this skill.", 409)
    session.questionStepMap[question.id] = step.id
    responseStep = {
      ...step,
      questionId: question.id,
      question: {
        questionId: question.id,
        prompt: question.prompt,
        options: question.options.map(({ id, text }) => ({ id, text })),
      },
    }
  } else {
    session.completedStepIds.push(step.id)
  }
  session.cursor += 1
  saveSession(session)
  return result({ step: responseStep })
})
