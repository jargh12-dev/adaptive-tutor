import { findStep, staticFallbacks } from "@/lib/content/lesson"
import { explanationOutputSchema, generateJson } from "@/lib/llm/client"
import { explainPrompt } from "@/lib/llm/prompts"
import { ApiError, parseInput, requireSession, result, withApi } from "@/lib/http"
import { getSession } from "@/lib/store"
import { explainSchema } from "@/lib/types"

export const POST = withApi(async ({ body }) => {
  const input = parseInput(explainSchema, body)
  requireSession(getSession(input.sessionId))
  const step = findStep(input.stepId)
  if (!step) throw new ApiError("Unknown lesson step")
  const fallback = staticFallbacks[step.id]?.[input.style] ?? step.body ?? "Review the lesson example and work through each fraction step in order."
  const generated = await generateJson(explainPrompt(step, input.style), explanationOutputSchema, { explanation: fallback })
  return result({ explanation: generated.data.explanation, source: generated.source }, generated.source)
})
