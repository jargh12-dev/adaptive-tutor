import { getQuestion } from "@/lib/content/lesson"
import { updateDifficulty } from "@/lib/engine/difficulty"
import { updateSkillMastery } from "@/lib/engine/mastery"
import { misconceptionForChoice, MISCONCEPTION_LABELS, MISCONCEPTION_REMEDIATION } from "@/lib/engine/misconceptions"
import { alternatePath, shouldSwitchPath } from "@/lib/engine/pathSelector"
import { ApiError, parseInput, requireSession, result, withApi } from "@/lib/http"
import { addAttempt, getSession, incrementMisconception, saveSession } from "@/lib/store"
import { answerSchema, type Attempt, type SkillId } from "@/lib/types"
import { randomUUID } from "node:crypto"

export const POST = withApi(({ body }) => {
  const input = parseInput(answerSchema, body)
  const session = requireSession(getSession(input.sessionId))
  if (!session.diagnosticCompleted || !session.pathId) throw new ApiError("Complete the diagnostic before submitting practice answers.", 409)
  const question = getQuestion(input.questionId)
  if (!question) throw new ApiError("Unknown question")
  const selectedOption = question.options.find((option) => option.id === input.choice)
  if (!selectedOption) throw new ApiError("Choice does not belong to this question")

  const correct = input.choice === question.correctOptionId
  const misconceptionTag = misconceptionForChoice(question.options, input.choice, question.correctOptionId)
  session.mastery = updateSkillMastery(session.mastery, question.skill, correct, input.hintsUsed, input.timeMs)
  session.streak = correct ? Math.max(0, session.streak) + 1 : Math.min(0, session.streak) - 1
  session.correctStreak = correct ? session.correctStreak + 1 : 0
  session.wrongStreak = correct ? 0 : session.wrongStreak + 1
  session.answersOnPath += 1
  if (misconceptionTag) incrementMisconception(session, misconceptionTag)

  const difficulty = updateDifficulty(session.difficulty, session.correctStreak, session.wrongStreak)
  session.difficulty = difficulty.difficulty
  if (difficulty.signal === "level_up") session.correctStreak = 0
  if (difficulty.signal === "reteach") {
    session.wrongStreak = 0
    session.reteachPending[question.skill] = true
  }
  const stepId = session.questionStepMap[input.questionId]
  if (stepId && !session.completedStepIds.includes(stepId)) session.completedStepIds.push(stepId)

  let nextAction: "continue" | "reteach" | "switch_path" | "level_up" = "continue"
  let reason = correct ? "You answered correctly, so we will continue with the next weakest skill." : "We recorded this attempt and will use it to guide the next practice step."
  if (misconceptionTag && shouldSwitchPath(session, misconceptionTag)) {
    const previousPath = session.pathId
    session.pathId = alternatePath(previousPath!)
    session.answersOnPath = 0
    nextAction = "switch_path"
    reason = `The ${MISCONCEPTION_LABELS[misconceptionTag].toLowerCase()} pattern repeated on the ${previousPath} path, so we are switching to ${session.pathId} explanations.`
  } else if (difficulty.signal === "reteach") {
    nextAction = "reteach"
    reason = `Two incorrect answers in a row suggest we should revisit ${question.skill.replaceAll("_", " ")} before continuing.`
  } else if (difficulty.signal === "level_up") {
    nextAction = "level_up"
    reason = `Three correct answers in a row earned a move to difficulty ${session.difficulty}.`
  }

  const attempt: Attempt = {
    attemptId: `a_${randomUUID().replaceAll("-", "").slice(0, 12)}`,
    sessionId: session.sessionId,
    questionId: question.id,
    skill: question.skill,
    choice: input.choice,
    correct,
    timeMs: input.timeMs,
    hintsUsed: input.hintsUsed,
    ...(misconceptionTag ? { misconceptionTag } : {}),
    masteryAfter: session.mastery[question.skill],
    createdAt: new Date().toISOString(),
  }
  addAttempt(attempt)
  saveSession(session)
  const feedback = correct
    ? question.feedbackCorrect
    : misconceptionTag
      ? `${question.feedbackByMisconception[misconceptionTag] ?? "Review the steps and try again."} ${MISCONCEPTION_REMEDIATION[misconceptionTag]}`
      : "That is not quite right. Review the worked example and try another problem."
  return result({
    correct,
    feedback,
    mastery: session.mastery,
    ...(misconceptionTag ? { misconceptionTag } : {}),
    nextAction,
    reason,
  })
})
