import { parseInput, result, withApi } from "@/lib/http"
import { createSession } from "@/lib/store"
import { sessionSchema } from "@/lib/types"

export const POST = withApi(({ body }) => {
  const input = parseInput(sessionSchema, body)
  const session = createSession(input.name)
  return result({ sessionId: session.sessionId })
})
