"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import useSWR from "swr"
import { AlertCircle, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { getDiagnosticQuestions } from "@/lib/api"
import type { AnswerRecord } from "@/lib/types"
import { useTutorStore } from "@/store/useTutorStore"
import { ProgressStepper } from "@/components/tutor/ProgressStepper"
import { QuestionCard } from "@/components/tutor/QuestionCard"
import { OptionList } from "@/components/tutor/OptionList"
import { fireAdaptationToast } from "@/components/tutor/AdaptationToast"

export default function DiagnosticPage() {
  const router = useRouter()
  const session = useTutorStore((state) => state.session)
  const diagnosticIndex = useTutorStore((state) => state.diagnosticIndex)
  const recordDiagnosticAnswer = useTutorStore((state) => state.recordDiagnosticAnswer)
  const completeDiagnostic = useTutorStore((state) => state.completeDiagnostic)
  const error = useTutorStore((state) => state.error)
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [startedAt, setStartedAt] = useState(() => Date.now())
  const [analyzing, setAnalyzing] = useState(false)
  const { data: questions, error: loadError, isLoading, mutate } = useSWR(session ? ["diagnostic", session.id] : null, ([, sessionId]) => getDiagnosticQuestions(sessionId))

  useEffect(() => { if (!session) router.replace("/") }, [router, session])
  const question = questions?.[diagnosticIndex]
  function recordAnswer(): AnswerRecord | null {
    if (!question || !selectedId) return null
    const option = question.options.find((item) => item.id === selectedId)
    const record: AnswerRecord = { questionId: question.id, selectedOptionId: selectedId, correct: selectedId === question.correctOptionId, timeTakenMs: Date.now() - startedAt, misconceptionId: option?.misconceptionId, hintsUsed: 0 }
    recordDiagnosticAnswer(record)
    return record
  }
  async function next() {
    if (!question || !selectedId) return
    const record = recordAnswer()
    if (!record) return
    setSelectedId(null)
    if (diagnosticIndex + 1 < (questions?.length ?? 0)) { setStartedAt(Date.now()); return }
    setAnalyzing(true)
    const answers = [...useTutorStore.getState().history]
    const result = await completeDiagnostic(answers)
    if (result) {
      fireAdaptationToast({ id: `diagnostic-${Date.now()}`, toPath: result.assignedPathId, reason: `We’ve placed you on the ${result.assignedPathId === "visual" ? "Visual explorer" : "Number strategist"} path because ${result.reason.charAt(0).toLowerCase()}${result.reason.slice(1)}`, triggeredBy: "diagnostic answers", timestamp: new Date().toISOString() })
      router.push(`/lesson/${result.assignedPathId}`)
    } else setAnalyzing(false)
  }

  return <main className="mx-auto max-w-3xl px-4 py-8 sm:px-6 sm:py-12"><div className="mb-7 flex items-start justify-between gap-4"><div><div className="mb-2 flex items-center gap-2 text-sm font-semibold text-primary"><span className="flex size-8 items-center justify-center rounded-xl bg-primary/10"><Sparkles aria-hidden="true" /></span>Let’s get to know how you think</div><h1 className="text-3xl font-semibold tracking-tight sm:text-4xl">A quick fraction check-in</h1><p className="mt-2 text-muted-foreground">No grades here. Your answers help us choose the right kind of explanation.</p></div><span className="hidden rounded-full bg-muted px-3 py-1.5 text-xs font-medium text-muted-foreground sm:block">About 2 minutes</span></div>
    {analyzing ? <Card className="rounded-3xl"><CardContent className="flex min-h-72 flex-col items-center justify-center p-8 text-center"><span className="mb-4 flex size-14 items-center justify-center rounded-2xl bg-primary/10 text-primary"><Sparkles className="animate-pulse" /></span><h2 className="text-xl font-semibold">Analyzing your answers…</h2><p className="mt-2 max-w-md text-sm leading-6 text-muted-foreground">We’re looking for the ideas behind your answers so we can choose how to teach, not just what to ask next.</p><div className="mt-6 flex gap-2"><span className="size-2 animate-bounce rounded-full bg-primary" /><span className="size-2 animate-bounce rounded-full bg-primary [animation-delay:120ms]" /><span className="size-2 animate-bounce rounded-full bg-primary [animation-delay:240ms]" /></div></CardContent></Card> : isLoading ? <div className="space-y-5"><Skeleton className="h-8 w-full rounded-full" /><Skeleton className="h-56 w-full rounded-3xl" /><Skeleton className="h-44 w-full rounded-3xl" /></div> : loadError ? <Card className="rounded-3xl"><CardContent className="flex flex-col items-center gap-3 p-8 text-center"><AlertCircle className="text-destructive" /><p className="font-semibold">We couldn’t load your check-in.</p><Button variant="outline" onClick={() => void mutate()}>Try again</Button></CardContent></Card> : question ? <div className="space-y-5"><ProgressStepper current={diagnosticIndex + 1} total={questions?.length ?? 6} /><QuestionCard question={question} eyebrow="No right or wrong feeling" /><Card className="rounded-3xl border-border/70 shadow-sm"><CardContent className="space-y-5 p-5 sm:p-7"><p className="text-sm font-medium text-muted-foreground">Choose the answer that feels right. You can use your keyboard: press 1, 2, 3, or 4.</p><OptionList options={question.options} selectedId={selectedId} onSelect={setSelectedId} /><div className="flex items-center justify-between border-t pt-4"><p className="text-xs text-muted-foreground">{diagnosticIndex + 1} of {questions?.length ?? 6}</p><Button onClick={() => void next()} disabled={!selectedId || useTutorStore.getState().isLoading} className="rounded-xl px-5">{diagnosticIndex + 1 === questions?.length ? "Find my learning path" : "Next question"}</Button></div></CardContent></Card>{error && <p role="alert" className="text-sm text-destructive">{error}</p>}</div> : <Card className="rounded-3xl"><CardContent className="p-8 text-center"><p>There aren’t any questions to show yet.</p><Button className="mt-4" onClick={() => void mutate()}>Reload questions</Button></CardContent></Card>}
  </main>
}
