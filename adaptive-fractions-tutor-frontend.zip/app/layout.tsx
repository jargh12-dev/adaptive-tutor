import { Analytics } from "@vercel/analytics/next"
import type { Metadata, Viewport } from "next"
import { Toaster } from "sonner"
import { TooltipProvider } from "@/components/ui/tooltip"
import { AppNav } from "@/components/AppNav"
import { DemoControls } from "@/components/tutor/DemoControls"
import "./globals.css"

export const metadata: Metadata = {
  title: "The Adaptive Tutor — Learn fractions your way",
  description: "A tutor that figures out why you’re stuck, adapts how it teaches, and explains what to try next.",
  applicationName: "The Adaptive Tutor",
}

export const viewport: Viewport = {
  colorScheme: "light dark",
  themeColor: [{ media: "(prefers-color-scheme: light)", color: "#fbfaf8" }, { media: "(prefers-color-scheme: dark)", color: "#17171b" }],
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en" data-scroll-behavior="smooth"><body className="min-h-screen antialiased"><TooltipProvider><AppNav />{children}<DemoControls /><Toaster position="top-right" richColors closeButton /></TooltipProvider>{process.env.NODE_ENV === "production" && <Analytics />}</body></html>
}
