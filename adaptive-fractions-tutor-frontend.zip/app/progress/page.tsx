"use client"

import Link from "next/link"
import useSWR from "swr"
import { ArrowLeft, ArrowRight, BarChart3, CalendarDays, ChartNoAxesCombined, Sparkles } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { getProgress } from "@/lib/api"
import { useTutorStore } from "@/store/useTutorStore"
import { MasteryBars } from "@/components/progress/MasteryBars"
import { SkillRadar } from "@/components/progress/SkillRadar"
import { MisconceptionList } from "@/components/progress/MisconceptionList"
import { NextStepCTA } from "@/components/progress/NextStepCTA"

export default function ProgressPage() {
  const session = useTutorStore((state) => state.session)
  const currentPathId = useTutorStore((state) => state.currentPathId)
  const nextReason = useTutorStore((state) => state.nextReason)
  const liveMastery = useTutorStore((state) => state.mastery)
  const { data, error, isLoading, mutate } = useSWR(session ? ["progress", session.id] : null, ([, sessionId]) => getProgress(sessionId))
  const pathId = currentPathId ?? "visual"
  return <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-12"><div className="mb-8 flex flex-wrap items-end justify-between gap-4"><div><Link href={session ? `/lesson/${pathId}` : "/"} className="mb-3 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"><ArrowLeft aria-hidden="true" />{session ? "Back to your lesson" : "Home"}</Link><div className="mb-2 flex items-center gap-2 text-sm font-semibold text-primary"><span className="flex size-8 items-center justify-center rounded-xl bg-primary/10"><ChartNoAxesCombined aria-hidden="true" /></span>Your learning snapshot</div><h1 className="text-3xl font-semibold tracking-tight sm:text-4xl">Look how far you’ve come.</h1><p className="mt-2 max-w-2xl text-muted-foreground">This is a picture of what’s clicking—and what we’ll help with next.</p></div><Badge variant="outline" className="rounded-full px-3 py-1.5"><CalendarDays data-icon="inline-start" /> Fractions · Learning profile</Badge></div>
    {!session ? <Card className="rounded-3xl"><CardContent className="flex flex-col items-center p-10 text-center"><span className="flex size-14 items-center justify-center rounded-2xl bg-primary/10 text-primary"><Sparkles aria-hidden="true" /></span><h2 className="mt-4 text-xl font-semibold">Your progress starts with a quick check-in</h2><p className="mt-2 max-w-md text-sm leading-6 text-muted-foreground">Start a fraction lesson and your tutor will build a learning snapshot just for you.</p><Button nativeButton={false} render={<Link href="/" />} className="mt-5 rounded-xl">Start a lesson<ArrowRight data-icon="inline-end" /></Button></CardContent></Card> : isLoading ? <div className="grid gap-5 lg:grid-cols-2"><Skeleton className="h-[360px] rounded-3xl" /><Skeleton className="h-[360px] rounded-3xl" /><Skeleton className="h-72 rounded-3xl lg:col-span-2" /><Skeleton className="h-44 rounded-3xl lg:col-span-2" /></div> : error || !data ? <Card className="rounded-3xl"><CardContent className="flex flex-col items-center gap-3 p-8 text-center"><BarChart3 className="text-muted-foreground" /><p className="font-semibold">Your progress is taking a moment.</p><p className="text-sm text-muted-foreground">Try again when you’re ready.</p><Button variant="outline" onClick={() => void mutate()}>Reload progress</Button></CardContent></Card> : <div className="space-y-5"><div className="grid gap-5 lg:grid-cols-2"><MasteryBars mastery={liveMastery ?? data.mastery} /><SkillRadar mastery={liveMastery ?? data.mastery} /></div><MisconceptionList misconceptions={data.misconceptions} pathId={pathId} /><Card className="rounded-3xl border-border/70 shadow-sm"><CardHeader><CardTitle>How your lesson adapted</CardTitle><CardDescription>Your tutor explains every strategy change.</CardDescription></CardHeader><CardContent>{data.adaptations.length ? <ol className="relative ml-2 space-y-5 border-l border-primary/20 pl-6">{data.adaptations.map((adaptation) => <li key={adaptation.id} className="relative"><span className="absolute -left-[31px] top-0.5 flex size-5 items-center justify-center rounded-full border-2 border-background bg-primary text-primary-foreground"><Sparkles /></span><div className="flex flex-wrap items-center gap-2"><span className="font-semibold">{adaptation.fromPath === "visual" ? "Visual explorer" : "Number strategist"}</span><ArrowRight className="text-muted-foreground" /><span className="font-semibold">{adaptation.toPath === "visual" ? "Visual explorer" : "Number strategist"}</span><span className="text-xs text-muted-foreground">{new Date(adaptation.timestamp).toLocaleDateString()}</span></div><p className="mt-1 text-sm leading-6 text-muted-foreground">{adaptation.reason}</p></li>)}</ol> : <p className="text-sm text-muted-foreground">No path changes yet. Your tutor will show the reason if a different teaching strategy becomes useful.</p>}</CardContent></Card><NextStepCTA pathId={pathId} reason={nextReason || "Keep building your fraction sense with one more short activity."} /></div>}
  </main>
}
