"use client"

import { useEffect, useMemo, useState } from "react"
import Link from "next/link"
import { useParams, useRouter } from "next/navigation"
import useSWR from "swr"
import { ArrowLeft, Check, Circle, Clock3, MessageCircleQuestion, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { getPath } from "@/lib/api"
import type { AnswerRecord, LessonStep, Misconception, PathId } from "@/lib/types"
import { useTutorStore } from "@/store/useTutorStore"
import { ExplanationPanel } from "@/components/tutor/ExplanationPanel"
import { ExampleCard } from "@/components/tutor/ExampleCard"
import { PracticeQuestion } from "@/components/tutor/PracticeQuestion"
import { HintButton } from "@/components/tutor/HintButton"
import { NextButton } from "@/components/tutor/NextButton"
import { PathBadge } from "@/components/tutor/PathBadge"
import { Progress } from "@/components/ui/progress"
import { WhyThisNextBox } from "@/components/tutor/WhyThisNextBox"
import { ChallengeDrawer } from "@/components/tutor/ChallengeDrawer"
import { fireAdaptationToast } from "@/components/tutor/AdaptationToast"

export default function LessonPage() {
  const params = useParams<{ pathId: string }>()
  const pathParam = params.pathId === "symbolic" ? "symbolic" : "visual"
  const router = useRouter()
  const session = useTutorStore((state) => state.session)
  const activePath = useTutorStore((state) => state.currentPathId)
  const pathId: PathId = activePath ?? pathParam
  const currentStepIndex = useTutorStore((state) => state.currentStepIndex)
  const advanceStep = useTutorStore((state) => state.advanceStep)
  const nextReason = useTutorStore((state) => state.nextReason)
  const history = useTutorStore((state) => state.history)
  const misconceptions = useTutorStore((state) => state.misconceptions)
  const latestHint = useTutorStore((state) => state.latestHint)
  const hintCount = useTutorStore((state) => state.hintCount)
  const requestHint = useTutorStore((state) => state.requestHint)
  const submitPracticeAnswer = useTutorStore((state) => state.submitPracticeAnswer)
  const isLoading = useTutorStore((state) => state.isLoading)
  const storeError = useTutorStore((state) => state.error)
  const stepOverrides = useTutorStore((state) => state.stepOverrides)
  const setCurrentStep = useTutorStore((state) => state.setCurrentStep)
  const setCurrentStepIndex = useTutorStore((state) => state.setCurrentStepIndex)
  const submitChallenge = useTutorStore((state) => state.submitChallenge)
  const challengeResponse = useTutorStore((state) => state.challengeResponse)
  const challengeLoading = useTutorStore((state) => state.isLoading)
  const challengeError = useTutorStore((state) => state.error)
  const [challengeOpen, setChallengeOpen] = useState(false)
  const { data: path, error: pathError, isLoading: pathLoading, mutate } = useSWR(["path", pathId], ([, id]) => getPath(id))
  const step = path?.steps[currentStepIndex]
  const [answerCompleted, setAnswerCompleted] = useState(false)

  useEffect(() => { if (!session) router.replace("/") }, [router, session])
  useEffect(() => { if (activePath && activePath !== pathParam) router.replace(`/lesson/${activePath}`) }, [activePath, pathParam, router])
  useEffect(() => { if (step) { setCurrentStep(step.id); setAnswerCompleted(history.some((record) => record.questionId === step.question?.id)) } }, [history, setCurrentStep, step])
  useEffect(() => {
    if (!path || typeof window === "undefined") return
    const focus = new URLSearchParams(window.location.search).get("focus")
    if (!focus) return
    const focusIndex = path.steps.findIndex((item) => item.question?.skill === focus)
    if (focusIndex >= 0) { setCurrentStepIndex(focusIndex); router.replace(`/lesson/${pathId}`) }
  }, [path, pathId, router, setCurrentStepIndex])

  const latestMisconception = useMemo(() => misconceptions[0], [misconceptions])
  async function onAnswer(record: AnswerRecord) {
    const adaptation = await submitPracticeAnswer(record)
    setAnswerCompleted(true)
    if (adaptation) fireAdaptationToast(adaptation)
  }
  function next() {
    if (currentStepIndex >= (path?.steps.length ?? 0) - 1) { router.push("/progress"); return }
    advanceStep()
    setAnswerCompleted(false)
  }
  const explanation = step ? stepOverrides[step.id] ?? step.body : ""
  const progress = path ? Math.round(((currentStepIndex + 1) / path.steps.length) * 100) : 0

  if (pathLoading || !session) return <main className="mx-auto grid max-w-6xl gap-6 px-4 py-8 sm:px-6 lg:grid-cols-[1fr_320px]"><div className="space-y-5"><Skeleton className="h-14 w-52 rounded-2xl" /><Skeleton className="h-64 rounded-3xl" /><Skeleton className="h-48 rounded-3xl" /></div><Skeleton className="hidden h-[500px] rounded-3xl lg:block" /></main>
  if (pathError || !path || !step) return <main className="mx-auto max-w-2xl px-4 py-12"><Card className="rounded-3xl"><CardContent className="flex flex-col items-center gap-3 p-8 text-center"><p className="font-semibold">We couldn’t load this learning path.</p><p className="text-sm text-muted-foreground">Your progress is safe. Try loading the lesson again.</p><Button variant="outline" onClick={() => void mutate()}>Try again</Button></CardContent></Card></main>

  return <main className="mx-auto max-w-6xl px-4 py-7 sm:px-6 sm:py-10"><div className="mb-6 flex flex-wrap items-center justify-between gap-4"><div><Link href="/diagnostic" className="mb-3 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"><ArrowLeft aria-hidden="true" />Your learning path</Link><div className="flex items-center gap-3"><span className="flex size-10 items-center justify-center rounded-2xl bg-primary/10 text-primary"><Sparkles aria-hidden="true" /></span><div><h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">Fractions, your way</h1><p className="text-sm text-muted-foreground">{session.learnerName ? `A little progress at a time, ${session.learnerName}.` : "A little progress at a time."}</p></div></div></div><PathBadge pathId={path.id} animated={useTutorStore.getState().adaptations.length > 1} /></div>
    <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_320px] lg:items-start"><div className="space-y-5">{step.type === "explain" ? <ExplanationPanel step={step} body={explanation} /> : step.type === "example" ? <ExampleCard step={{ ...step, body: explanation }} /> : <><ExplanationPanel step={{ ...step, type: "explain" }} body={explanation} /><PracticeQuestion key={step.id} step={step} misconceptions={misconceptions} onSubmit={(record) => void onAnswer(record)} hintsUsed={hintCount} isLoading={isLoading} /><HintButton hints={step.hints ?? []} hint={latestHint} hintCount={hintCount} onRequest={() => void requestHint(step.id)} loading={isLoading} /></>}
      {storeError && <p role="alert" className="text-sm text-destructive">{storeError}</p>}
      <div className="flex items-center justify-between gap-3 rounded-2xl border bg-card p-4"><p className="text-xs text-muted-foreground sm:text-sm">{answerCompleted ? "Great work. Ready for what’s next?" : step.type === "practice" ? "Choose an answer to continue." : "Take your time. You can revisit this idea later."}</p><NextButton onClick={next} disabled={step.type === "practice" && !answerCompleted} isLast={currentStepIndex >= path.steps.length - 1} /></div>
    </div>
    <aside className="space-y-4 lg:sticky lg:top-24"><Card className="rounded-3xl border-border/70 shadow-sm"><CardContent className="p-5"><div className="flex items-center justify-between"><p className="text-sm font-semibold">Your lesson path</p><span className="inline-flex items-center gap-1 text-xs text-muted-foreground"><Clock3 /> 15 min</span></div><div className="mt-4 flex items-center justify-between text-xs text-muted-foreground"><span>Step {currentStepIndex + 1} of {path.steps.length}</span><span>{progress}%</span></div><Progress value={progress} className="mt-2 h-2" /><div className="mt-5 space-y-2">{path.steps.map((item: LessonStep, index: number) => <button type="button" key={item.id} onClick={() => { if (index <= currentStepIndex) { useTutorStore.setState({ currentStepIndex: index }); setAnswerCompleted(false) } }} disabled={index > currentStepIndex} className={`flex w-full items-start gap-3 rounded-xl p-3 text-left transition ${index === currentStepIndex ? "bg-primary/[0.07] text-foreground" : "text-muted-foreground hover:bg-muted/60"}`} aria-current={index === currentStepIndex ? "step" : undefined}><span className={`mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-full ${index < currentStepIndex ? "bg-emerald-100 text-emerald-700" : index === currentStepIndex ? "bg-primary text-primary-foreground" : "bg-muted"}`}>{index < currentStepIndex ? <Check /> : index === currentStepIndex ? <span className="text-xs font-bold">{index + 1}</span> : <Circle />}</span><span><span className="block text-sm font-semibold">{item.title}</span><span className="mt-0.5 block text-xs capitalize">{item.type}</span></span></button>)}</div></CardContent></Card>
      <WhyThisNextBox reason={nextReason} misconception={latestMisconception as Misconception | undefined} skill={step.question?.skill} />
      <Button variant="outline" className="h-12 w-full rounded-xl" onClick={() => setChallengeOpen(true)}><MessageCircleQuestion data-icon="inline-start" />Challenge the tutor</Button>
    </aside></div>
    <ChallengeDrawer open={challengeOpen} onOpenChange={setChallengeOpen} step={step} body={explanation} response={challengeResponse} loading={challengeLoading} error={challengeError} onSubmit={(message) => void submitChallenge(message)} onApply={(body) => useTutorStore.getState().applyRevisedExplanation(step.id, body)} />
  </main>
}
