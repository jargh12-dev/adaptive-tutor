"use client"

import { create } from "zustand"
import { challengeExplanation, createSession, getHint, submitAnswer, submitDiagnostic } from "@/lib/api"
import type { Adaptation, AnswerRecord, ChallengeResponse, DiagnosticResult, Mastery, Misconception, PathId, Session } from "@/lib/types"

interface TutorState {
  session: Session | null
  mastery: Mastery | null
  currentPathId: PathId | null
  currentStepIndex: number
  currentStepId: string | null
  history: AnswerRecord[]
  misconceptions: Misconception[]
  adaptations: Adaptation[]
  nextReason: string
  diagnosticIndex: number
  isLoading: boolean
  error: string | null
  stepOverrides: Record<string, string>
  latestHint: string | null
  challengeResponse: ChallengeResponse | null
  consecutiveWrong: number
  hintCount: number
  startSession: (name?: string) => Promise<void>
  recordDiagnosticAnswer: (record: AnswerRecord) => void
  completeDiagnostic: (answers: AnswerRecord[]) => Promise<DiagnosticResult | null>
  submitPracticeAnswer: (record: AnswerRecord) => Promise<Adaptation | undefined>
  requestHint: (stepId: string) => Promise<void>
  advanceStep: () => void
  applyAdaptation: (adaptation: Adaptation) => void
  submitChallenge: (message: string) => Promise<void>
  applyRevisedExplanation: (stepId: string, body: string) => void
  setCurrentStep: (stepId: string) => void
  setCurrentStepIndex: (index: number) => void
  setDemoMastery: (level: "low" | "high") => void
  reset: () => void
}

const initialState = {
  session: null, mastery: null, currentPathId: null, currentStepIndex: 0, currentStepId: null,
  history: [] as AnswerRecord[], misconceptions: [] as Misconception[], adaptations: [] as Adaptation[],
  nextReason: "We’ll choose a learning strategy based on what your answers tell us.", diagnosticIndex: 0,
  isLoading: false, error: null, stepOverrides: {} as Record<string, string>, latestHint: null,
  challengeResponse: null, consecutiveWrong: 0, hintCount: 0,
}

export const useTutorStore = create<TutorState>((set, get) => ({
  ...initialState,
  // TODO: replace mock call with real API once backend is ready
  startSession: async (name) => {
    set({ isLoading: true, error: null })
    try { const session = await createSession(name); set({ session, isLoading: false }) }
    catch (error) { set({ error: error instanceof Error ? error.message : "Could not start your session.", isLoading: false }) }
  },
  // TODO: replace mock call with real API once backend is ready
  recordDiagnosticAnswer: (record) => set((state) => ({ history: [...state.history.filter((item) => item.questionId !== record.questionId), record], diagnosticIndex: state.diagnosticIndex + 1 })),
  // TODO: replace mock call with real API once backend is ready
  completeDiagnostic: async (answers) => {
    const session = get().session
    if (!session) { set({ error: "Your session has ended. Start again to continue." }); return null }
    set({ isLoading: true, error: null })
    try {
      const result = await submitDiagnostic(session.id, answers)
      const adaptation: Adaptation = { id: `diagnostic-${Date.now()}`, toPath: result.assignedPathId, reason: result.reason, triggeredBy: "diagnostic answers", timestamp: new Date().toISOString() }
      set({ mastery: result.mastery, misconceptions: result.misconceptions, currentPathId: result.assignedPathId, adaptations: [adaptation], nextReason: result.reason, isLoading: false })
      return result
    } catch (error) { set({ error: error instanceof Error ? error.message : "We couldn’t analyze your answers.", isLoading: false }); return null }
  },
  // TODO: replace mock call with real API once backend is ready
  submitPracticeAnswer: async (record) => {
    const session = get().session
    if (!session) return undefined
    set({ isLoading: true, error: null })
    try {
      const result = await submitAnswer(session.id, record)
      const state = get()
      const consecutiveWrong = record.correct ? 0 : state.consecutiveWrong + 1
      set((current) => ({ history: [...current.history, record], mastery: result.mastery, misconceptions: result.misconceptions.length ? result.misconceptions : current.misconceptions, nextReason: result.nextReason, consecutiveWrong, isLoading: false }))
      if (result.adaptation && consecutiveWrong >= 2) {
        const adaptation = { ...result.adaptation, fromPath: state.currentPathId ?? result.adaptation.fromPath, toPath: state.currentPathId === "visual" ? "symbolic" as const : "visual" as const }
        get().applyAdaptation(adaptation)
        return adaptation
      }
      return undefined
    } catch (error) { set({ error: error instanceof Error ? error.message : "Your answer could not be saved.", isLoading: false }); return undefined }
  },
  // TODO: replace mock call with real API once backend is ready
  requestHint: async (stepId) => {
    const session = get().session
    if (!session) return
    const hintLevel = Math.min(get().hintCount + 1, 3) as 1 | 2 | 3
    try { const result = await getHint(session.id, stepId, hintLevel); set({ latestHint: result.hint, hintCount: hintLevel }) }
    catch (error) { set({ error: error instanceof Error ? error.message : "A hint is unavailable right now." }) }
  },
  // TODO: replace mock call with real API once backend is ready
  advanceStep: () => set((state) => ({ currentStepIndex: state.currentStepIndex + 1, latestHint: null, hintCount: 0, challengeResponse: null })),
  // TODO: replace mock call with real API once backend is ready
  applyAdaptation: (adaptation) => set((state) => ({ currentPathId: adaptation.toPath, currentStepIndex: 0, adaptations: [...state.adaptations, adaptation], nextReason: adaptation.reason, latestHint: null, hintCount: 0, challengeResponse: null, consecutiveWrong: 0 })),
  // TODO: replace mock call with real API once backend is ready
  submitChallenge: async (message) => {
    const session = get().session
    const stepId = get().currentStepId
    if (!session || !stepId) return
    set({ isLoading: true, error: null, challengeResponse: null })
    try { const response = await challengeExplanation({ sessionId: session.id, stepId, message }); set({ challengeResponse: response, isLoading: false }) }
    catch (error) { set({ error: error instanceof Error ? error.message : "We couldn’t review that challenge.", isLoading: false }) }
  },
  // TODO: replace mock call with real API once backend is ready
  applyRevisedExplanation: (stepId, body) => set((state) => ({ stepOverrides: { ...state.stepOverrides, [stepId]: body } })),
  // TODO: replace mock call with real API once backend is ready
  setCurrentStep: (stepId) => set({ currentStepId: stepId, challengeResponse: null, latestHint: null, hintCount: 0 }),
  // TODO: replace mock call with real API once backend is ready
  setCurrentStepIndex: (index) => set({ currentStepIndex: index, latestHint: null, hintCount: 0, challengeResponse: null }),
  // TODO: replace mock call with real API once backend is ready
  setDemoMastery: (level) => set({ mastery: level === "low" ? { equivalence: 0.22, comparison: 0.25, number_line: 0.2, part_whole: 0.33, simplifying: 0.18 } : { equivalence: 0.94, comparison: 0.91, number_line: 0.88, part_whole: 0.96, simplifying: 0.9 } }),
  // TODO: replace mock call with real API once backend is ready
  reset: () => { if (typeof window !== "undefined") window.sessionStorage.removeItem("tutor-practice-attempts"); set(initialState) },
}))
