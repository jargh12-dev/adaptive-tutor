# The Adaptive Tutor

A client-first learning experience for fraction comparison and equivalence. The mock flow diagnoses misconceptions, adapts the teaching strategy, supports challenges to explanations, and visualizes mastery.

## File tree

```text
app/
  page.tsx
  layout.tsx
  globals.css
  diagnostic/page.tsx
  lesson/[pathId]/page.tsx
  progress/page.tsx
components/
  AppNav.tsx
  tutor/
    AdaptationToast.tsx
    ChallengeDrawer.tsx
    DemoControls.tsx
    ExampleCard.tsx
    ExplanationPanel.tsx
    HintButton.tsx
    MathText.tsx
    NextButton.tsx
    OptionList.tsx
    PathBadge.tsx
    PracticeQuestion.tsx
    ProgressStepper.tsx
    QuestionCard.tsx
    WhyThisNextBox.tsx
  progress/
    MasteryBars.tsx
    MisconceptionList.tsx
    NextStepCTA.tsx
    SkillRadar.tsx
  visuals/
    FractionBar.tsx
    FractionNumberLine.tsx
lib/
  api.ts
  mocks.ts
  types.ts
  utils.ts
store/
  useTutorStore.ts
README.md
```

## Mock data switch

Mocks are enabled by default. Set `NEXT_PUBLIC_USE_MOCKS=false` to switch API client calls to the typed HTTP branch. The application expects the API endpoints below to be provided by a backend when mocks are disabled.

## API endpoint contracts

| Method | Endpoint | Request | Response |
| --- | --- | --- | --- |
| POST | `/api/session` | `{ name?: string }` | `Session` |
| GET | `/api/diagnostic?sessionId=…` | Session query | `DiagnosticQuestion[]` (6 questions) |
| POST | `/api/diagnostic/submit` | `{ sessionId, answers: AnswerRecord[] }` | `{ mastery, misconceptions, assignedPathId, reason }` |
| GET | `/api/path/:id` | `visual` or `symbolic` | `LearningPath` |
| POST | `/api/answer` | `{ sessionId, record: AnswerRecord }` | `{ mastery, misconceptions, nextReason, adaptation? }` |
| POST | `/api/hint` | `{ sessionId, stepId, level: 1\|2\|3 }` | `{ hint: string }` |
| POST | `/api/challenge` | `ChallengeRequest` | `ChallengeResponse` |
| GET | `/api/progress?sessionId=…` | Session query | `{ mastery, misconceptions, adaptations, history }` |

All shared request and response shapes are defined in `lib/types.ts`. Mock mode simulates 400–800 ms of network latency.
