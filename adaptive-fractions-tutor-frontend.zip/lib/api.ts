import { challengeResponses, defaultMastery, diagnosticQuestions, diagnosticResult, mockProgress, paths } from "./mocks"
import type { Adaptation, AnswerRecord, AnswerResult, ChallengeRequest, ChallengeResponse, DiagnosticQuestion, DiagnosticResult, LearningPath, PathId, ProgressPayload, Session } from "./types"

export const USE_MOCKS = process.env.NEXT_PUBLIC_USE_MOCKS !== "false"

async function fetchJson<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, { ...init, headers: { "Content-Type": "application/json", ...init?.headers } })
  if (!response.ok) throw new Error(`Request failed (${response.status})`)
  return response.json() as Promise<T>
}

const wait = () => new Promise<void>((resolve) => setTimeout(resolve, 400 + Math.random() * 400))
const post = (body: unknown): RequestInit => ({ method: "POST", body: JSON.stringify(body) })

export async function createSession(name?: string): Promise<Session> {
  // TODO(backend): Connect this typed request to the production API route.
  if (!USE_MOCKS) return fetchJson<Session>("/api/session", post({ name }))
  await wait()
  return { id: `session-${Date.now()}`, learnerName: name?.trim() || undefined, startedAt: new Date().toISOString(), topic: "Fractions: Comparing & Equivalence" }
}

export async function getDiagnosticQuestions(sessionId: string): Promise<DiagnosticQuestion[]> {
  // TODO(backend): Connect this typed request to the production API route.
  if (!USE_MOCKS) return fetchJson<DiagnosticQuestion[]>(`/api/diagnostic?sessionId=${encodeURIComponent(sessionId)}`)
  await wait()
  return diagnosticQuestions
}

export async function submitDiagnostic(sessionId: string, answers: AnswerRecord[]): Promise<DiagnosticResult> {
  // TODO(backend): Connect this typed request to the production API route.
  if (!USE_MOCKS) return fetchJson<DiagnosticResult>("/api/diagnostic/submit", post({ sessionId, answers }))
  await wait()
  return { ...diagnosticResult, mastery: { ...diagnosticResult.mastery }, misconceptions: [...diagnosticResult.misconceptions] }
}

export async function getPath(pathId: PathId): Promise<LearningPath> {
  // TODO(backend): Connect this typed request to the production API route.
  if (!USE_MOCKS) return fetchJson<LearningPath>(`/api/path/${pathId}`)
  await wait()
  return paths[pathId]
}

export async function submitAnswer(sessionId: string, record: AnswerRecord): Promise<AnswerResult> {
  // TODO(backend): Connect this typed request to the production API route.
  if (!USE_MOCKS) return fetchJson<AnswerResult>("/api/answer", post({ sessionId, record }))
  await wait()
  const recent = typeof window !== "undefined" ? JSON.parse(window.sessionStorage.getItem("tutor-practice-attempts") || "[]") as boolean[] : []
  const attempts = [...recent, record.correct].slice(-2)
  if (typeof window !== "undefined") window.sessionStorage.setItem("tutor-practice-attempts", JSON.stringify(attempts))
  const adaptation: Adaptation | undefined = attempts.length === 2 && attempts.every((correct) => !correct) ? {
    id: `adapt-${Date.now()}`, fromPath: "visual", toPath: "symbolic",
    reason: "Two practice questions in a row were tricky. A clear, step-by-step strategy may make the comparison easier.",
    triggeredBy: "two consecutive practice errors", timestamp: new Date().toISOString()
  } : undefined
  return {
    mastery: { ...defaultMastery, [record.questionId.includes("comparison") ? "comparison" : "equivalence"]: record.correct ? 0.72 : 0.38 },
    misconceptions: record.misconceptionId ? [diagnosticResult.misconceptions[0]] : [],
    nextReason: record.correct ? "You’re ready to build on this idea with a slightly deeper comparison." : "Let’s strengthen this skill using a strategy matched to your last answer.",
    adaptation,
  }
}

export async function getHint(sessionId: string, stepId: string, level: 1 | 2 | 3): Promise<{ hint: string }> {
  // TODO(backend): Connect this typed request to the production API route.
  if (!USE_MOCKS) return fetchJson<{ hint: string }>("/api/hint", post({ sessionId, stepId, level }))
  await wait()
  const step = Object.values(paths).flatMap((path) => path.steps).find((item) => item.id === stepId)
  return { hint: step?.hints?.[level - 1] ?? ["Read the question carefully.", "Try drawing or rewriting the fractions.", "Check whether the parts are the same size."][level - 1] }
}

export async function challengeExplanation(request: ChallengeRequest): Promise<ChallengeResponse> {
  // TODO(backend): Connect this typed request to the production API route.
  if (!USE_MOCKS) return fetchJson<ChallengeResponse>("/api/challenge", post(request))
  await wait()
  const message = request.message.toLowerCase()
  if (message.includes("incorrect") || message.includes("wrong")) return challengeResponses[0]
  if (message.includes("example")) return challengeResponses[1]
  return challengeResponses[2]
}

export async function getProgress(sessionId: string): Promise<ProgressPayload> {
  // TODO(backend): Connect this typed request to the production API route.
  if (!USE_MOCKS) return fetchJson<ProgressPayload>(`/api/progress?sessionId=${encodeURIComponent(sessionId)}`)
  await wait()
  return mockProgress
}
