export type Skill = "equivalence" | "comparison" | "number_line" | "part_whole" | "simplifying"
export type PathId = "visual" | "symbolic"

export interface Misconception {
  id: string
  label: string
  description: string
  skill: Skill
  evidence: string
}

export interface Option {
  id: string
  text: string
  misconceptionId?: string
}

export interface DiagnosticQuestion {
  id: string
  skill: Skill
  prompt: string
  options: Option[]
  correctOptionId: string
  difficulty: 1 | 2 | 3
  fractionVisual?: FractionBarProps
}

export interface AnswerRecord {
  questionId: string
  selectedOptionId: string
  correct: boolean
  timeTakenMs: number
  misconceptionId?: string
  hintsUsed: number
}

export interface FractionBarProps {
  numerator: number
  denominator: number
  shaded?: number
  comparison?: { numerator: number; denominator: number }
  showLabel?: boolean
  color?: string
  size?: "sm" | "md" | "lg"
}

export interface LessonStep {
  id: string
  type: "explain" | "example" | "practice"
  title: string
  body: string
  fractionVisual?: FractionBarProps
  numberLine?: { label: string; value: number }[]
  question?: DiagnosticQuestion
  hints?: string[]
}

export interface LearningPath {
  id: PathId
  label: string
  description: string
  steps: LessonStep[]
}

export type Mastery = Record<Skill, number>

export interface Adaptation {
  id: string
  fromPath?: PathId
  toPath: PathId
  reason: string
  triggeredBy: string
  timestamp: string
}

export interface Session {
  id: string
  learnerName?: string
  startedAt: string
  topic: string
}

export interface ChallengeRequest {
  sessionId: string
  stepId: string
  message: string
}

export interface ChallengeResponse {
  reply: string
  verdict: "explanation_revised" | "explanation_stands" | "needs_clarification"
  revisedBody?: string
}

export interface DiagnosticResult {
  mastery: Mastery
  misconceptions: Misconception[]
  assignedPathId: PathId
  reason: string
}

export interface AnswerResult {
  mastery: Mastery
  misconceptions: Misconception[]
  nextReason: string
  adaptation?: Adaptation
}

export interface ProgressPayload {
  mastery: Mastery
  misconceptions: Misconception[]
  adaptations: Adaptation[]
  history: AnswerRecord[]
}
