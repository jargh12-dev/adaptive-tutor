import type { Adaptation, ChallengeResponse, DiagnosticQuestion, LearningPath, Mastery, Misconception, PathId, ProgressPayload } from "./types"

export const misconceptions: Misconception[] = [
  { id: "bigger_denominator_bigger_fraction", label: "Bigger denominator means bigger fraction", description: "A larger denominator cuts the same whole into more, smaller pieces.", skill: "comparison", evidence: "You chose 1/8 as larger than 1/3 because 8 is greater than 3." },
  { id: "add_numerators_and_denominators", label: "Adding across the fraction bar", description: "When adding fractions, the pieces need the same size before you combine them.", skill: "equivalence", evidence: "You combined 1/2 and 1/3 to make 2/5." },
  { id: "whole_number_bias", label: "Comparing digits separately", description: "The numerator and denominator work together; compare the size of the parts, not just the digits.", skill: "number_line", evidence: "You placed 1/4 to the right of 1/2 on the number line." },
  { id: "numerator_only", label: "Looking only at the top number", description: "A fraction describes how many equal parts out of the total number of parts.", skill: "part_whole", evidence: "You described 3 shaded pieces as 3/4 even though the whole had 5 pieces." },
  { id: "simplification_stops_early", label: "Stopping before simplest form", description: "An equivalent fraction is simplest only when the numerator and denominator share no factor greater than 1.", skill: "simplifying", evidence: "You reduced 6/8 to 2/4, then stopped while both numbers could still be divided by 2." },
]

export const diagnosticQuestions: DiagnosticQuestion[] = [
  { id: "d1", skill: "comparison", prompt: "Which fraction is **greater**?", options: [{ id: "a", text: "\\(\\frac{1}{3}\\)" }, { id: "b", text: "\\(\\frac{1}{8}\\)", misconceptionId: "bigger_denominator_bigger_fraction" }, { id: "c", text: "They are equal", misconceptionId: "whole_number_bias" }, { id: "d", text: "Not sure", misconceptionId: "whole_number_bias" }], correctOptionId: "a", difficulty: 1, fractionVisual: { numerator: 1, denominator: 3, comparison: { numerator: 1, denominator: 8 }, showLabel: true } },
  { id: "d2", skill: "equivalence", prompt: "Which fraction is equivalent to **\\(\\frac{1}{2}\\)**?", options: [{ id: "a", text: "\\(\\frac{2}{3}\\)", misconceptionId: "add_numerators_and_denominators" }, { id: "b", text: "\\(\\frac{3}{6}\\)" }, { id: "c", text: "\\(\\frac{1}{3}\\)", misconceptionId: "bigger_denominator_bigger_fraction" }, { id: "d", text: "\\(\\frac{2}{5}\\)", misconceptionId: "add_numerators_and_denominators" }], correctOptionId: "b", difficulty: 1, fractionVisual: { numerator: 1, denominator: 2, comparison: { numerator: 3, denominator: 6 }, showLabel: true } },
  { id: "d3", skill: "number_line", prompt: "Where does **\\(\\frac{1}{4}\\)** belong?", options: [{ id: "a", text: "Between 0 and \\(\\frac{1}{2}\\)" }, { id: "b", text: "Between \\(\\frac{1}{2}\\) and 1", misconceptionId: "whole_number_bias" }, { id: "c", text: "At 1", misconceptionId: "whole_number_bias" }, { id: "d", text: "Before 0", misconceptionId: "whole_number_bias" }], correctOptionId: "a", difficulty: 1 },
  { id: "d4", skill: "part_whole", prompt: "A chocolate bar has 5 equal pieces. You eat 3. What fraction did you eat?", options: [{ id: "a", text: "\\(\\frac{3}{5}\\)" }, { id: "b", text: "\\(\\frac{3}{2}\\)", misconceptionId: "numerator_only" }, { id: "c", text: "\\(\\frac{5}{3}\\)", misconceptionId: "numerator_only" }, { id: "d", text: "\\(\\frac{2}{5}\\)", misconceptionId: "numerator_only" }], correctOptionId: "a", difficulty: 1, fractionVisual: { numerator: 3, denominator: 5, showLabel: true } },
  { id: "d5", skill: "comparison", prompt: "Compare **\\(\\frac{3}{4}\\)** and **\\(\\frac{2}{3}\\)**.", options: [{ id: "a", text: "\\(\\frac{3}{4} > \\frac{2}{3}\\)" }, { id: "b", text: "\\(\\frac{2}{3} > \\frac{3}{4}\\)", misconceptionId: "whole_number_bias" }, { id: "c", text: "They are equal", misconceptionId: "whole_number_bias" }, { id: "d", text: "Not enough information", misconceptionId: "whole_number_bias" }], correctOptionId: "a", difficulty: 2 },
  { id: "d6", skill: "simplifying", prompt: "Which is the simplest form of **\\(\\frac{6}{8}\\)**?", options: [{ id: "a", text: "\\(\\frac{3}{4}\\)" }, { id: "b", text: "\\(\\frac{2}{4}\\)", misconceptionId: "simplification_stops_early" }, { id: "c", text: "\\(\\frac{6}{4}\\)", misconceptionId: "numerator_only" }, { id: "d", text: "\\(\\frac{1}{2}\\)", misconceptionId: "simplification_stops_early" }], correctOptionId: "a", difficulty: 2 },
]

const visualPath: LearningPath = {
  id: "visual", label: "Visual explorer", description: "Build fraction sense with shaded bars, number lines, and everyday examples.", steps: [
    { id: "v1", type: "explain", title: "A fraction is a fair share", body: "A fraction tells us how many equal parts we have out of all the equal parts in one whole. The bottom number names the size of the pieces; the top number tells how many we count.\n\nFor \\(\\frac{3}{4}\\), the whole is split into 4 equal pieces and we have 3 of them.", fractionVisual: { numerator: 3, denominator: 4, showLabel: true } },
    { id: "v2", type: "example", title: "Share a chocolate bar", body: "1. Start with two identical chocolate bars, each representing one whole.\n2. Split one bar into 2 equal pieces and keep 1. Split the other into 4 equal pieces and keep 2.\n3. Both shares cover the same amount of chocolate, so \\(\\frac{1}{2}=\\frac{2}{4}\\).", fractionVisual: { numerator: 1, denominator: 2, comparison: { numerator: 2, denominator: 4 }, showLabel: true } },
    { id: "v3", type: "practice", title: "Spot the equal share", body: "Which fraction covers the same amount as one half?", question: { id: "vp1", skill: "equivalence", prompt: "Choose the fraction equivalent to **\\(\\frac{1}{2}\\)**.", options: [{ id: "a", text: "\\(\\frac{2}{4}\\)" }, { id: "b", text: "\\(\\frac{2}{3}\\)", misconceptionId: "whole_number_bias" }, { id: "c", text: "\\(\\frac{1}{4}\\)", misconceptionId: "bigger_denominator_bigger_fraction" }, { id: "d", text: "\\(\\frac{3}{4}\\)", misconceptionId: "whole_number_bias" }], correctOptionId: "a", difficulty: 1 }, hints: ["Look for a bar that is half shaded.", "If you split each half into 2 equal pieces, how many pieces are shaded?", "Multiply the top and bottom of \\(\\frac{1}{2}\\) by 2."], fractionVisual: { numerator: 1, denominator: 2, comparison: { numerator: 2, denominator: 4 }, showLabel: true } },
    { id: "v4", type: "explain", title: "Compare by the amount shaded", body: "When denominators differ, compare the size of the shaded part of each same-size whole. A bigger denominator means smaller pieces, not a bigger fraction.\n\nOn this bar, \\(\\frac{2}{3}\\) reaches farther than \\(\\frac{3}{5}\\).", fractionVisual: { numerator: 2, denominator: 3, comparison: { numerator: 3, denominator: 5 }, showLabel: true }, numberLine: [{ label: "3/5", value: 0.6 }, { label: "2/3", value: 0.667 }] },
    { id: "v5", type: "practice", title: "Which share is larger?", body: "Use the bars to compare the two fractions.", question: { id: "vp2", skill: "comparison", prompt: "Which is greater: **\\(\\frac{2}{3}\\)** or **\\(\\frac{3}{5}\\)**?", options: [{ id: "a", text: "\\(\\frac{2}{3}\\)" }, { id: "b", text: "\\(\\frac{3}{5}\\)", misconceptionId: "bigger_denominator_bigger_fraction" }, { id: "c", text: "They are equal", misconceptionId: "whole_number_bias" }, { id: "d", text: "Not sure", misconceptionId: "whole_number_bias" }], correctOptionId: "a", difficulty: 2 }, hints: ["Compare the bars using the same width whole.", "Which shaded bar reaches farther to the right?", "Two thirds is about 0.67; three fifths is 0.6."], fractionVisual: { numerator: 2, denominator: 3, comparison: { numerator: 3, denominator: 5 }, showLabel: true } },
  ]
}

const symbolicPath: LearningPath = {
  id: "symbolic", label: "Number strategist", description: "Use fraction rules, common denominators, and clear worked steps.", steps: [
    { id: "s1", type: "explain", title: "Equivalent fractions keep the value", body: "Multiply or divide the numerator and denominator by the **same nonzero number** to make an equivalent fraction.\n\n\\(\\frac{a}{b} = \\frac{a\\times k}{b\\times k}\\). The ratio stays unchanged because we multiply by \\(\\frac{k}{k}=1\\)." },
    { id: "s2", type: "example", title: "Build an equivalent fraction", body: "To express \\(\\frac{1}{2}\\) with denominator 6, multiply top and bottom by 3:\n\n1. Find the scale factor: \\(2\\times3=6\\).\n2. Apply it to the numerator: \\(1\\times3=3\\).\n3. So \\(\\frac{1}{2}=\\frac{3}{6}\\).", fractionVisual: { numerator: 1, denominator: 2, comparison: { numerator: 3, denominator: 6 }, showLabel: true } },
    { id: "s3", type: "practice", title: "Apply the same factor", body: "Keep numerator and denominator in proportion.", question: { id: "sp1", skill: "equivalence", prompt: "Complete **\\(\\frac{2}{5} = \\frac{?}{20}\\)**.", options: [{ id: "a", text: "8" }, { id: "b", text: "4", misconceptionId: "numerator_only" }, { id: "c", text: "10", misconceptionId: "numerator_only" }, { id: "d", text: "18", misconceptionId: "numerator_only" }], correctOptionId: "a", difficulty: 2 }, hints: ["What number times 5 gives 20?", "The scale factor is 4. Apply it to the numerator too.", "2 × 4 = 8, so the missing numerator is 8."], fractionVisual: { numerator: 2, denominator: 5, comparison: { numerator: 8, denominator: 20 }, showLabel: true } },
    { id: "s4", type: "explain", title: "Compare with common denominators", body: "To compare fractions, rewrite them with a common denominator. For \\(\\frac{3}{4}\\) and \\(\\frac{2}{3}\\), use 12:\n\n\\(\\frac{3}{4}=\\frac{9}{12}\\), while \\(\\frac{2}{3}=\\frac{8}{12}\\). Since 9 > 8, \\(\\frac{3}{4}>\\frac{2}{3}\\)." },
    { id: "s5", type: "example", title: "Compare with cross products", body: "For positive denominators, cross multiplication compares two fractions without finding a common denominator.\n\n1. Compare \\(\\frac{5}{8}\\) and \\(\\frac{2}{3}\\).\n2. Multiply diagonally: \\(5\\times3=15\\) and \\(2\\times8=16\\).\n3. Since 15 is less than 16, \\(\\frac{5}{8}<\\frac{2}{3}\\).", fractionVisual: { numerator: 5, denominator: 8, comparison: { numerator: 2, denominator: 3 }, showLabel: true } },
    { id: "s6", type: "practice", title: "Compare step by step", body: "Find a common denominator, then compare the numerators.", question: { id: "sp2", skill: "comparison", prompt: "Which statement is true?", options: [{ id: "a", text: "\\(\\frac{5}{8} > \\frac{2}{3}\\)", misconceptionId: "whole_number_bias" }, { id: "b", text: "\\(\\frac{2}{3} > \\frac{5}{8}\\)" }, { id: "c", text: "They are equal", misconceptionId: "whole_number_bias" }, { id: "d", text: "\\(\\frac{5}{8}=\\frac{10}{12}\\)", misconceptionId: "whole_number_bias" }], correctOptionId: "b", difficulty: 2 }, hints: ["Use 24 as a common denominator.", "Convert to 15/24 and 16/24.", "16/24 is greater than 15/24, so 2/3 is greater."], fractionVisual: { numerator: 5, denominator: 8, comparison: { numerator: 2, denominator: 3 }, showLabel: true } },
  ]
}

export const paths: Record<PathId, LearningPath> = { visual: visualPath, symbolic: symbolicPath }

export const defaultMastery: Mastery = { equivalence: 0.48, comparison: 0.52, number_line: 0.38, part_whole: 0.72, simplifying: 0.42 }
export const diagnosticResult = {
  mastery: { equivalence: 0.45, comparison: 0.36, number_line: 0.32, part_whole: 0.68, simplifying: 0.42 },
  misconceptions: [misconceptions[0], misconceptions[2]],
  assignedPathId: "visual" as PathId,
  reason: "Your answers show that shaded parts and number lines will make fraction size easier to see before we introduce more rules."
}

export const mockAdaptation: Adaptation = {
  id: "adapt-demo", fromPath: "visual", toPath: "symbolic",
  reason: "You missed two visual comparison questions in a row. Let’s try a clear common-denominator strategy instead.",
  triggeredBy: "two consecutive practice errors", timestamp: new Date().toISOString()
}

export const mockProgress: ProgressPayload = {
  mastery: { equivalence: 0.68, comparison: 0.47, number_line: 0.54, part_whole: 0.83, simplifying: 0.39 },
  misconceptions: [misconceptions[0], misconceptions[1], misconceptions[2]],
  adaptations: [{ id: "adapt-1", fromPath: "visual", toPath: "symbolic", reason: "Two comparison misses suggested a step-by-step common-denominator approach would help.", triggeredBy: "practice pattern", timestamp: "2026-09-18T10:24:00.000Z" }],
  history: [
    { questionId: "d1", selectedOptionId: "b", correct: false, timeTakenMs: 12000, misconceptionId: "bigger_denominator_bigger_fraction", hintsUsed: 0 },
    { questionId: "d2", selectedOptionId: "b", correct: true, timeTakenMs: 9000, hintsUsed: 0 },
    { questionId: "vp1", selectedOptionId: "b", correct: false, timeTakenMs: 17000, misconceptionId: "bigger_denominator_bigger_fraction", hintsUsed: 1 },
  ]
}

export const challengeResponses: ChallengeResponse[] = [
  { verdict: "explanation_revised", reply: "You’re right to question that. I made the comparison sound like the denominator alone decides the answer. The numerator matters too, so let’s compare equal-sized pieces.", revisedBody: "To compare fractions, rewrite them with a common denominator or compare their shaded amounts. A larger denominator means smaller pieces; both numerator and denominator determine the fraction's size." },
  { verdict: "explanation_stands", reply: "That’s a thoughtful challenge. This step is correct because we multiply both parts by the same factor, which is the same as multiplying by 1. Let’s check it with the fraction bars." },
  { verdict: "needs_clarification", reply: "I want to make sure I understand what feels confusing. Is it the meaning of the denominator, or why we multiply both numbers by the same factor?" },
]
