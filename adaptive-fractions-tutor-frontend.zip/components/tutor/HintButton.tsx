"use client"

import { Lightbulb } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export interface Props { hints: string[]; hint: string | null; hintCount: number; onRequest: () => void; loading?: boolean }
export function HintButton({ hints, hint, hintCount, onRequest, loading = false }: Props) {
  const total = Math.min(hints.length, 3)
  const exhausted = hintCount >= total
  return <div className="space-y-3"><Button variant="outline" className="rounded-xl" onClick={onRequest} disabled={loading || hints.length === 0 || exhausted}><Lightbulb data-icon="inline-start" />{loading ? "Finding a hint…" : exhausted ? `All ${total} hints used` : hintCount ? `Need another hint? ${hintCount} of ${total} used` : "Need a hint?"}</Button>{hint && <Card className="rounded-2xl border-amber-200 bg-amber-50/70 dark:border-amber-900 dark:bg-amber-950/20"><CardContent className="flex gap-3 p-4 text-sm text-amber-950 dark:text-amber-100"><Lightbulb className="mt-0.5 shrink-0" /><p><span className="font-semibold">Hint {hintCount} of {total}: </span>{hint}</p></CardContent></Card>}</div>
}
