"use client"

import { useState } from "react"
import { CheckCircle2, CircleHelp, XCircle } from "lucide-react"
import type { AnswerRecord, LessonStep, Misconception } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { OptionList } from "./OptionList"
import { MathText } from "./MathText"

export interface Props { step: LessonStep; misconceptions: Misconception[]; onSubmit: (record: AnswerRecord) => void; hintsUsed: number; isLoading?: boolean }
export function PracticeQuestion({ step, misconceptions, onSubmit, hintsUsed, isLoading = false }: Props) {
  const question = step.question
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [answered, setAnswered] = useState(false)
  const [startedAt] = useState(() => Date.now())
  if (!question) return null
  const selected = question.options.find((option) => option.id === selectedId)
  const correct = selectedId === question.correctOptionId
  const misconception = !correct && selected?.misconceptionId ? misconceptions.find((item) => item.id === selected.misconceptionId) : null
  function submit() {
    if (!selected || answered || !question) return
    setAnswered(true)
    onSubmit({ questionId: question.id, selectedOptionId: selected.id, correct, timeTakenMs: Date.now() - startedAt, misconceptionId: selected.misconceptionId, hintsUsed })
  }
  return <Card className="rounded-3xl border-border/70 shadow-sm"><CardHeader><CardDescription className="font-semibold uppercase tracking-[0.14em] text-primary">Your turn</CardDescription><CardTitle className="text-xl"><MathText text={question.prompt} /></CardTitle><p className="text-sm text-muted-foreground">{step.body}</p></CardHeader><CardContent className="space-y-4"><OptionList options={question.options} selectedId={selectedId} onSelect={setSelectedId} correctOptionId={question.correctOptionId} showFeedback={answered} disabled={answered} />
    {answered && <div role="status" className={`rounded-2xl border p-4 ${correct ? "border-emerald-200 bg-emerald-50 text-emerald-900 dark:border-emerald-900 dark:bg-emerald-950/30 dark:text-emerald-100" : "border-amber-200 bg-amber-50 text-amber-950 dark:border-amber-900 dark:bg-amber-950/30 dark:text-amber-100"}`}>
      <div className="flex gap-3">{correct ? <CheckCircle2 className="mt-0.5 shrink-0 text-emerald-600" /> : <CircleHelp className="mt-0.5 shrink-0 text-amber-600" />}<div><p className="font-semibold">{correct ? "That’s right — nice reasoning." : "Not quite. Let’s look at the thinking behind it."}</p>{misconception ? <p className="mt-1 text-sm"><span className="font-semibold">A pattern to watch: {misconception.label}.</span> {misconception.description}</p> : !correct && <p className="mt-1 text-sm">Compare the value of each fraction, not just one number. You can use a hint and try the next example.</p>}</div></div>
      {!correct && <XCircle className="sr-only" aria-label="Incorrect" />}
    </div>}
    {!answered ? <Button className="h-11 rounded-xl px-5" onClick={submit} disabled={!selectedId || isLoading}>{isLoading ? "Checking…" : "Check answer"}</Button> : <p className="text-sm font-medium text-muted-foreground">Answer saved to your learning profile.</p>}
  </CardContent></Card>
}
