import { BrainCircuit } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { Misconception, Skill } from "@/lib/types"

export interface Props { reason: string; misconception?: Misconception; skill?: Skill }
const skillLabels: Record<Skill, string> = { equivalence: "Equivalent fractions", comparison: "Comparing fractions", number_line: "Number line sense", part_whole: "Part and whole", simplifying: "Simplifying" }
export function WhyThisNextBox({ reason, misconception, skill }: Props) {
  return <Card className="rounded-2xl border-primary/15 bg-primary/[0.035] shadow-none"><CardContent className="p-5"><div className="mb-2 flex items-center gap-2 text-sm font-semibold"><BrainCircuit className="text-primary" />Why this next?</div><p className="text-sm leading-6 text-muted-foreground">{reason}</p>{(misconception || skill) && <div className="mt-3 flex flex-wrap gap-2">{misconception && <Badge variant="outline" className="text-xs">{misconception.label}</Badge>}{skill && <Badge variant="outline" className="text-xs">{skillLabels[skill]}</Badge>}</div>}</CardContent></Card>
}
