import { Eye, Sigma } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip"
import type { PathId } from "@/lib/types"

export interface Props { pathId: PathId; animated?: boolean }
const copy = {
  visual: { label: "Visual explorer", detail: "Learn with fraction bars, number lines, and everyday examples.", Icon: Eye },
  symbolic: { label: "Number strategist", detail: "Learn with fraction rules and step-by-step comparisons.", Icon: Sigma },
}

export function PathBadge({ pathId, animated = false }: Props) {
  const { label, detail, Icon } = copy[pathId]
  return <Tooltip><TooltipTrigger render={<span tabIndex={0} />}><Badge variant="secondary" className={`gap-1.5 rounded-full px-3 py-1 text-sm ${animated ? "animate-in fade-in slide-in-from-right-2 duration-500" : ""}`}><Icon aria-hidden="true" />{label}</Badge></TooltipTrigger><TooltipContent>{detail}</TooltipContent></Tooltip>
}
