import { InlineMath, BlockMath } from "react-katex"
import "katex/dist/katex.min.css"

export interface Props { text: string; className?: string }

function renderInline(text: string, keyPrefix: string) {
  const parts = text.split(/(\\\([\s\S]*?\\\)|\*\*[^*]+\*\*)/g).filter(Boolean)
  return parts.map((part, index) => {
    if (part.startsWith("\\(") && part.endsWith("\\)")) return <InlineMath key={`${keyPrefix}-math-${index}`} math={part.slice(2, -2)} />
    if (part.startsWith("**") && part.endsWith("**")) {
      const content = part.slice(2, -2)
      const math = content.match(/^\\\(([\s\S]*?)\\\)$/)
      return <strong key={`${keyPrefix}-bold-${index}`} className="font-semibold text-foreground">{math ? <InlineMath math={math[1]} /> : renderInline(content, `${keyPrefix}-bold-${index}`)}</strong>
    }
    return <span key={`${keyPrefix}-text-${index}`}>{part}</span>
  })
}

export function MathText({ text, className }: Props) {
  const blocks = text.split(/\n\s*\n/).filter((block) => block.trim())
  return <div className={className}>
    {blocks.map((block, index) => {
      const trimmed = block.trim()
      if (trimmed.startsWith("$$") && trimmed.endsWith("$$")) return <div className="my-3 overflow-x-auto" key={index}><BlockMath math={trimmed.slice(2, -2)} /></div>
      const lines = trimmed.split("\n")
      const isList = lines.every((line) => /^\s*(\d+\.|[-*])\s+/.test(line))
      if (isList) return <ol className="my-3 list-decimal space-y-2 pl-5" key={index}>{lines.map((line, lineIndex) => <li key={lineIndex}>{renderInline(line.replace(/^\s*(\d+\.|[-*])\s+/, ""), `${index}-${lineIndex}`)}</li>)}</ol>
      return <p className="my-2 leading-7" key={index}>{lines.map((line, lineIndex) => <span key={lineIndex}>{lineIndex > 0 && <br />}{renderInline(line, `${index}-${lineIndex}`)}</span>)}</p>
    })}
  </div>
}
