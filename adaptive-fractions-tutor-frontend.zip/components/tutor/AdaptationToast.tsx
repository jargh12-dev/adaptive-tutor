import { toast } from "sonner"
import { Sparkles } from "lucide-react"
import type { Adaptation } from "@/lib/types"

export function fireAdaptationToast(adaptation: Adaptation) {
  toast("Adapting your lesson", {
    description: adaptation.reason,
    duration: 7500,
    icon: <Sparkles aria-hidden="true" className="text-primary" />,
    className: "border-l-4 border-l-primary",
  })
}
