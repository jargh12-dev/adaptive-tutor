"use client"

import { useState } from "react"
import { Check, ChevronRight, RotateCcw } from "lucide-react"
import type { LessonStep } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { MathText } from "./MathText"
import { FractionBar } from "@/components/visuals/FractionBar"

export interface Props { step: LessonStep }
export function ExampleCard({ step }: Props) {
  const [revealed, setRevealed] = useState(1)
  const parts = step.body.split(/\n(?=\d+\.)/).filter(Boolean)
  const canReveal = revealed < parts.length
  return <Card className="rounded-3xl border-border/70 shadow-sm"><CardHeader><div className="flex items-center justify-between gap-3"><div><p className="mb-1 text-xs font-bold uppercase tracking-[0.14em] text-primary">Worked example</p><CardTitle className="text-xl">{step.title}</CardTitle></div><span className="rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">Step {Math.min(revealed, parts.length)} of {parts.length}</span></div></CardHeader><CardContent className="space-y-4"><div className="space-y-3">{parts.slice(0, revealed).map((part, index) => <div key={index} className="flex gap-3 rounded-2xl bg-muted/50 p-4"><span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">{index === 0 && parts.length === 1 ? <Check aria-hidden="true" /> : index + 1}</span><MathText text={part.replace(/^\d+\.\s*/, "")} className="text-sm text-muted-foreground" /></div>)}</div>{step.fractionVisual && <div className="rounded-2xl bg-muted/30 p-4"><FractionBar {...step.fractionVisual} /></div>}<Button variant="outline" size="sm" onClick={() => setRevealed(canReveal ? revealed + 1 : 1)}>{canReveal ? <>Reveal next step <ChevronRight data-icon="inline-end" /></> : <>Start again <RotateCcw data-icon="inline-end" /></>}</Button></CardContent></Card>
}
