"use client"

import { useEffect } from "react"
import { Check, X } from "lucide-react"
import type { Option } from "@/lib/types"
import { MathText } from "./MathText"

export interface Props { options: Option[]; selectedId: string | null; onSelect: (id: string) => void; correctOptionId?: string; showFeedback?: boolean; disabled?: boolean }
export function OptionList({ options, selectedId, onSelect, correctOptionId, showFeedback = false, disabled = false }: Props) {
  useEffect(() => {
    function handleKey(event: KeyboardEvent) {
      if (event.altKey || event.ctrlKey || event.metaKey || !/^[1-4]$/.test(event.key)) return
      const target = event.target as HTMLElement
      if (["INPUT", "TEXTAREA"].includes(target.tagName)) return
      const option = options[Number(event.key) - 1]
      if (option && !disabled) onSelect(option.id)
    }
    window.addEventListener("keydown", handleKey)
    return () => window.removeEventListener("keydown", handleKey)
  }, [disabled, onSelect, options])

  return <div role="radiogroup" aria-label="Answer options" className="grid gap-3 sm:grid-cols-2">
    {options.map((option, index) => {
      const selected = selectedId === option.id
      const isCorrect = showFeedback && option.id === correctOptionId
      const isWrong = showFeedback && selected && !isCorrect
      return <button key={option.id} type="button" role="radio" aria-checked={selected} disabled={disabled} onClick={() => onSelect(option.id)} className={`group flex min-h-[68px] items-center gap-3 rounded-2xl border p-4 text-left transition-all hover:border-primary/50 hover:bg-primary/[0.03] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-default ${selected ? "border-primary bg-primary/[0.06] ring-1 ring-primary/20" : "border-border bg-background"} ${isCorrect ? "border-emerald-500 bg-emerald-50 dark:bg-emerald-950/30" : ""} ${isWrong ? "border-rose-400 bg-rose-50 dark:bg-rose-950/25" : ""}`}>
        <span className={`flex size-8 shrink-0 items-center justify-center rounded-lg border text-sm font-semibold ${selected ? "border-primary bg-primary text-primary-foreground" : "border-border bg-muted text-muted-foreground"}`}>{String.fromCharCode(65 + index)}</span>
        <span className="min-w-0 flex-1"><MathText text={option.text} className="font-medium" /></span>
        {isCorrect && <Check className="text-emerald-600" aria-label="Correct answer" />}{isWrong && <X className="text-rose-600" aria-label="Incorrect answer" />}
      </button>
    })}
  </div>
}
