"use client"

import { useState } from "react"
import { Check, MessageCircleQuestion, Send, Sparkles } from "lucide-react"
import type { ChallengeResponse, LessonStep } from "@/lib/types"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { Textarea } from "@/components/ui/textarea"
import { MathText } from "./MathText"

export interface Props { open: boolean; onOpenChange: (open: boolean) => void; step: LessonStep; body: string; response: ChallengeResponse | null; loading: boolean; error: string | null; onSubmit: (message: string) => void; onApply: (body: string) => void }
const quickReasons = ["This seems incorrect", "I don’t understand this step", "Show me another example"]
const verdicts: Record<ChallengeResponse["verdict"], { label: string; style: string }> = {
  explanation_revised: { label: "Explanation revised", style: "bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-200" },
  explanation_stands: { label: "Explanation stands", style: "bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-200" },
  needs_clarification: { label: "Needs clarification", style: "bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-100" },
}
export function ChallengeDrawer({ open, onOpenChange, step, body, response, loading, error, onSubmit, onApply }: Props) {
  const [message, setMessage] = useState("")
  const [applied, setApplied] = useState(false)
  function submit() { if (!message.trim()) return; onSubmit(message.trim()) }
  return <Sheet open={open} onOpenChange={onOpenChange}><SheetContent side="right" className="flex w-full flex-col gap-0 overflow-y-auto sm:max-w-lg">
    <SheetHeader className="border-b pb-5"><div className="mb-2 flex size-10 items-center justify-center rounded-xl bg-primary/10 text-primary"><MessageCircleQuestion aria-hidden="true" /></div><SheetTitle className="text-xl">Challenge the tutor</SheetTitle><SheetDescription>Question an explanation. Your tutor will take your concern seriously.</SheetDescription></SheetHeader>
    <div className="flex-1 space-y-5 py-5"><div className="rounded-2xl bg-muted/50 p-4"><p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Current explanation · {step.title}</p><MathText text={body} className="line-clamp-5 text-sm text-muted-foreground" /></div>
      <div><label htmlFor="challenge-message" className="mb-2 block text-sm font-semibold">What seems wrong or confusing?</label><Textarea id="challenge-message" rows={4} value={message} onChange={(event) => setMessage(event.target.value)} placeholder="Tell me which part you’d like me to revisit…" className="rounded-2xl" /></div>
      <div className="flex flex-wrap gap-2" aria-label="Quick challenge ideas">{quickReasons.map((reason) => <button type="button" key={reason} onClick={() => setMessage(reason)} className="rounded-full border bg-background px-3 py-2 text-xs text-muted-foreground transition hover:border-primary hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">{reason}</button>)}</div>
      <Button onClick={submit} disabled={loading || !message.trim()} className="w-full rounded-xl">{loading ? "Reviewing your challenge…" : "Send challenge"}{!loading && <Send data-icon="inline-end" />}</Button>
      {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
      {response && <div className="space-y-3 rounded-2xl border p-4"><div className="flex flex-wrap items-center justify-between gap-2"><p className="flex items-center gap-2 font-semibold"><Sparkles className="text-primary" />Tutor response</p><Badge className={verdicts[response.verdict].style}>{verdicts[response.verdict].label}</Badge></div><p className="rounded-2xl bg-primary/[0.06] p-4 text-sm leading-6">{response.reply}</p>{response.revisedBody && <div className="space-y-3"><div className="rounded-2xl border border-emerald-200 bg-emerald-50/70 p-4 dark:border-emerald-900 dark:bg-emerald-950/20"><p className="mb-2 text-xs font-semibold uppercase tracking-wide text-emerald-800 dark:text-emerald-200">Updated explanation</p><MathText text={response.revisedBody} className="text-sm" /></div><Button variant="outline" className="w-full rounded-xl" onClick={() => { onApply(response.revisedBody ?? ""); setApplied(true) }} disabled={applied}>{applied ? "Applied to this lesson" : "Apply updated explanation"}{applied && <Check data-icon="inline-end" />}</Button></div>}</div>}
    </div>
  </SheetContent></Sheet>
}
