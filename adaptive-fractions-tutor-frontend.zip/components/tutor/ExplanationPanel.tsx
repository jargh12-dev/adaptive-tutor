import type { LessonStep } from "@/lib/types"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { FractionBar } from "@/components/visuals/FractionBar"
import { FractionNumberLine } from "@/components/visuals/FractionNumberLine"
import { MathText } from "./MathText"

export interface Props { step: LessonStep; body?: string }
export function ExplanationPanel({ step, body }: Props) {
  return <Card className="rounded-3xl border-border/70 shadow-sm"><CardHeader><CardDescription className="font-semibold uppercase tracking-[0.14em] text-primary">{step.type === "explain" ? "The idea" : "Let’s unpack it"}</CardDescription><CardTitle className="text-2xl sm:text-[1.7rem]">{step.title}</CardTitle></CardHeader><CardContent className="space-y-5 text-base text-muted-foreground"><MathText text={body ?? step.body} />{step.fractionVisual && <div className="rounded-2xl bg-[#f7f6ff] p-5 dark:bg-muted/50"><FractionBar {...step.fractionVisual} /></div>}{step.numberLine && <FractionNumberLine points={step.numberLine} />}</CardContent></Card>
}
