import type { DiagnosticQuestion } from "@/lib/types"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { MathText } from "./MathText"
import { FractionBar } from "@/components/visuals/FractionBar"

export interface Props { question: DiagnosticQuestion; eyebrow?: string }
export function QuestionCard({ question, eyebrow = "Take your time" }: Props) {
  return <Card className="rounded-3xl border-border/70 shadow-sm">
    <CardHeader className="gap-2 pb-3"><CardDescription className="font-semibold uppercase tracking-[0.14em] text-primary">{eyebrow}</CardDescription><CardTitle className="text-2xl leading-snug sm:text-3xl"><MathText text={question.prompt} /></CardTitle></CardHeader>
    {question.fractionVisual && <CardContent className="pt-2"><div className="rounded-2xl bg-muted/50 p-5"><FractionBar {...question.fractionVisual} size="md" /></div></CardContent>}
  </Card>
}
