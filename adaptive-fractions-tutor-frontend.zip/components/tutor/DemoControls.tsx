"use client"

import { useState } from "react"
import { FlaskConical, RotateCcw, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useTutorStore } from "@/store/useTutorStore"
import { fireAdaptationToast } from "@/components/tutor/AdaptationToast"

export interface Props {}
export function DemoControls(_props: Props) {
  const [open, setOpen] = useState(false)
  const { currentPathId, applyAdaptation, setDemoMastery, reset } = useTutorStore()
  function forcePathSwitch() {
    const adaptation = { id: `demo-${Date.now()}`, fromPath: currentPathId ?? "visual", toPath: currentPathId === "symbolic" ? "visual" as const : "symbolic" as const, reason: "Demo adaptation: we changed teaching strategy so you can compare both learning paths.", triggeredBy: "demo control", timestamp: new Date().toISOString() }
    applyAdaptation(adaptation)
    fireAdaptationToast(adaptation)
  }
  if (process.env.NODE_ENV === "production") return null
  return <div className="fixed bottom-4 right-4 z-40">
    {open ? <div className="w-64 rounded-2xl border bg-background p-4 shadow-xl"><div className="mb-3 flex items-center justify-between"><p className="flex items-center gap-2 text-sm font-semibold"><FlaskConical className="text-primary" />Demo controls</p><Button variant="ghost" size="icon-sm" aria-label="Close demo controls" onClick={() => setOpen(false)}><X /></Button></div><div className="flex flex-col gap-2"><Button size="sm" variant="outline" onClick={forcePathSwitch}>Force path switch</Button><div className="grid grid-cols-2 gap-2"><Button size="sm" variant="outline" onClick={() => setDemoMastery("low")}>Set mastery low</Button><Button size="sm" variant="outline" onClick={() => setDemoMastery("high")}>Set mastery high</Button></div><Button size="sm" variant="ghost" onClick={reset}><RotateCcw data-icon="inline-start" />Reset session</Button></div></div> : <Button className="rounded-full shadow-lg" onClick={() => setOpen(true)}><FlaskConical data-icon="inline-start" />Demo controls</Button>}
  </div>
}
