import { ArrowRight, Check } from "lucide-react"
import { Button } from "@/components/ui/button"

export interface Props { onClick: () => void; disabled?: boolean; isLast?: boolean; label?: string }
export function NextButton({ onClick, disabled = false, isLast = false, label }: Props) {
  return <Button className="h-12 rounded-xl px-6 text-base" onClick={onClick} disabled={disabled}>{label ?? (isLast ? "See my progress" : "Continue lesson")} {isLast ? <Check data-icon="inline-end" /> : <ArrowRight data-icon="inline-end" />}</Button>
}
