import { Check } from "lucide-react"
import { Progress } from "@/components/ui/progress"

export interface Props { current: number; total: number; label?: string }
export function ProgressStepper({ current, total, label = "Question" }: Props) {
  const progress = Math.min((current / total) * 100, 100)
  return <div className="flex items-center gap-4" aria-label={`${label} ${current} of ${total}`}>
    <div className="flex shrink-0 items-center gap-2 text-sm font-medium text-muted-foreground"><span className="flex size-7 items-center justify-center rounded-full bg-primary/10 text-primary"><Check aria-hidden="true" /></span>{label} <span className="text-foreground">{current} of {total}</span></div>
    <Progress value={progress} className="h-2 flex-1" aria-label={`${label} progress`} />
  </div>
}
