"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { BookOpenCheck, ChartNoAxesColumnIncreasing, Moon, Sparkles, Sun } from "lucide-react"
import { Button } from "@/components/ui/button"
import { PathBadge } from "@/components/tutor/PathBadge"
import { useTutorStore } from "@/store/useTutorStore"

export interface Props {}
export function AppNav(_props: Props) {
  const pathname = usePathname()
  const currentPathId = useTutorStore((state) => state.currentPathId)
  const [isDarkMode, setIsDarkMode] = useState(false)

  function toggleTheme() {
    const nextIsDarkMode = !isDarkMode
    document.documentElement.classList.toggle("dark", nextIsDarkMode)
    setIsDarkMode(nextIsDarkMode)
  }

  return <header className="sticky top-0 z-30 border-b border-border/60 bg-background/90 backdrop-blur-xl"><div className="mx-auto flex h-[72px] max-w-6xl items-center justify-between gap-4 px-4 sm:px-6">
    <Link href="/" className="flex items-center gap-3 rounded-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring" aria-label="The Adaptive Tutor home"><span className="flex size-10 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-sm"><BookOpenCheck aria-hidden="true" /></span><span className="hidden leading-tight sm:block"><span className="block font-bold tracking-tight">the adaptive tutor</span><span className="text-xs text-muted-foreground">Your learning, understood.</span></span></Link>
    <div className="flex items-center gap-2 sm:gap-4">{currentPathId && pathname.startsWith("/lesson") && <PathBadge pathId={currentPathId} />}<Button type="button" variant="ghost" size="icon-lg" onClick={toggleTheme} aria-label={isDarkMode ? "Switch to light mode" : "Switch to dark mode"} aria-pressed={isDarkMode} title={isDarkMode ? "Switch to light mode" : "Switch to dark mode"}>{isDarkMode ? <Sun aria-hidden="true" /> : <Moon aria-hidden="true" />}</Button>{pathname !== "/progress" && <Button variant="ghost" size="sm" nativeButton={false} render={<Link href="/progress" />} className="gap-2 rounded-xl"><ChartNoAxesColumnIncreasing data-icon="inline-start" /> <span className="hidden sm:inline">My progress</span></Button>}{pathname === "/" && <span className="hidden items-center gap-1 rounded-full bg-muted px-3 py-2 text-xs font-medium text-muted-foreground md:flex"><Sparkles className="text-primary" />Learning that adapts</span>}</div>
  </div></header>
}
