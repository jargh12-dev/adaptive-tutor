export interface NumberLinePoint { label: string; value: number }
export interface Props { points: NumberLinePoint[]; title?: string }
export function FractionNumberLine({ points, title = "Fractions shown on a number line from zero to one" }: Props) {
  const xFor = (value: number) => 22 + Math.min(Math.max(value, 0), 1) * 356
  return <div className="w-full overflow-hidden rounded-2xl bg-white/80 p-3 dark:bg-background/50"><svg viewBox="0 0 400 70" className="h-auto w-full" role="img" aria-label={`${title}: ${points.map((point) => `${point.label} at ${point.value}`).join(", ")}`}>
    <title>{title}</title>
    <line x1="22" y1="39" x2="378" y2="39" stroke="#c8c4d8" strokeWidth="4" strokeLinecap="round" />
    {[0, 0.25, 0.5, 0.75, 1].map((value) => <g key={value}><line x1={xFor(value)} y1="32" x2={xFor(value)} y2="47" stroke="#aaa5bd" strokeWidth="2" /><text x={xFor(value)} y="64" textAnchor="middle" fill="#77728b" fontSize="10">{value === 0 ? "0" : value === 0.5 ? "1/2" : value === 1 ? "1" : ""}</text></g>)}
    {points.map((point, index) => <g key={`${point.label}-${point.value}`}><line x1={xFor(point.value)} y1="25" x2={xFor(point.value)} y2="39" stroke={index % 2 === 0 ? "#7567e8" : "#e8a23a"} strokeWidth="2" /><circle cx={xFor(point.value)} cy="39" r="6" fill={index % 2 === 0 ? "#7567e8" : "#e8a23a"} stroke="white" strokeWidth="2" /><text x={xFor(point.value)} y={index % 2 === 0 ? "13" : "24"} textAnchor="middle" fill={index % 2 === 0 ? "#5e50cb" : "#ae6f12"} fontSize="11" fontWeight="600">{point.label}</text></g>)}
  </svg></div>
}
