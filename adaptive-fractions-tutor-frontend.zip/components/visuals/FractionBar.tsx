import type { FractionBarProps } from "@/lib/types"

export interface Props extends FractionBarProps {}

export function FractionBar({ numerator, denominator, shaded, comparison, showLabel = false, color = "#7567e8", size = "md" }: Props) {
  const barHeight = size === "sm" ? 18 : size === "lg" ? 36 : 26
  const width = 400
  const rows = comparison ? [{ n: numerator, d: denominator }, { n: comparison.numerator, d: comparison.denominator }] : [{ n: shaded ?? numerator, d: denominator }]
  return (
    <div className="w-full space-y-3" role="group" aria-label={comparison ? `Comparing ${numerator}/${denominator} and ${comparison.numerator}/${comparison.denominator}` : `${numerator} of ${denominator} equal parts shaded`}>
      {rows.map((row, rowIndex) => {
        const fill = Math.min(Math.max(row.n, 0), row.d) / row.d
        return <div className="flex items-center gap-3" key={`${rowIndex}-${row.n}-${row.d}`}>
          {showLabel && <span className="w-12 shrink-0 text-sm font-semibold text-foreground">{row.n}/{row.d}</span>}
          <svg className="h-auto w-full max-w-[400px]" viewBox={`0 0 ${width} ${barHeight}`} role="img" aria-label={`${row.n} out of ${row.d} parts shaded`}>
            <title>{`${row.n} of ${row.d} equal parts shaded`}</title>
            <rect x="0" y="0" width={width} height={barHeight} rx="7" fill="#f1efff" />
            <rect x="0" y="0" width={width * fill} height={barHeight} rx="7" fill={rowIndex === 1 ? "#f6b955" : color} />
            {Array.from({ length: Math.max(row.d - 1, 0) }, (_, index) => <line key={index} x1={(width / row.d) * (index + 1)} y1="0" x2={(width / row.d) * (index + 1)} y2={barHeight} stroke="#ffffff" strokeWidth="3" />)}
            <rect x="1" y="1" width={width - 2} height={barHeight - 2} rx="6" fill="none" stroke="#dcd8f4" strokeWidth="2" />
          </svg>
        </div>
      })}
    </div>
  )
}
