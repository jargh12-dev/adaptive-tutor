import Link from "next/link"
import { ArrowRight, Compass } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import type { PathId } from "@/lib/types"

export interface Props { pathId: PathId; reason: string }
export function NextStepCTA({ pathId, reason }: Props) {
  return <Card className="overflow-hidden rounded-3xl border-0 bg-primary text-primary-foreground shadow-md"><CardContent className="flex flex-col gap-6 p-6 sm:flex-row sm:items-center sm:justify-between sm:p-8"><div className="flex items-start gap-4"><span className="flex size-12 shrink-0 items-center justify-center rounded-2xl bg-white/15"><Compass aria-hidden="true" /></span><div><p className="text-sm font-semibold text-primary-foreground/80">A good next step</p><h2 className="mt-1 text-2xl font-bold">Keep building your fraction sense</h2><p className="mt-2 max-w-xl text-sm leading-6 text-primary-foreground/80">{reason}</p></div></div><Button nativeButton={false} render={<Link href={`/lesson/${pathId}`} />} variant="secondary" className="h-12 shrink-0 rounded-xl px-5">Continue learning<ArrowRight data-icon="inline-end" /></Button></CardContent></Card>
}
