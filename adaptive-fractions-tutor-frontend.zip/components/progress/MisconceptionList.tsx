import Link from "next/link"
import { ArrowUpRight, Lightbulb } from "lucide-react"
import type { Misconception, PathId } from "@/lib/types"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export interface Props { misconceptions: Misconception[]; pathId: PathId }
export function MisconceptionList({ misconceptions, pathId }: Props) {
  return <Card className="rounded-3xl border-border/70 shadow-sm"><CardHeader><CardTitle>Patterns we’re working on</CardTitle><CardDescription>These are clues, not labels. Each one helps us choose a better explanation.</CardDescription></CardHeader><CardContent className="space-y-3">{misconceptions.length ? misconceptions.map((item) => <div key={item.id} className="rounded-2xl border bg-background p-4"><div className="flex items-start gap-3"><span className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-200"><Lightbulb aria-hidden="true" /></span><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><h3 className="font-semibold">{item.label}</h3><Badge variant="outline" className="text-[10px]">{item.skill.replaceAll("_", " ")}</Badge></div><p className="mt-1 text-sm leading-6 text-muted-foreground">{item.description}</p><p className="mt-3 rounded-xl bg-muted/60 px-3 py-2 text-xs text-muted-foreground"><span className="font-semibold text-foreground">What we noticed: </span>{item.evidence}</p><Button nativeButton={false} variant="link" size="sm" className="mt-2 h-auto px-0" render={<Link href={`/lesson/${pathId}?focus=${item.skill}`} />}>Practice this<ArrowUpRight data-icon="inline-end" /></Button></div></div></div>) : <p className="rounded-xl bg-muted/50 p-4 text-sm text-muted-foreground">No patterns to work on yet. Keep practicing and we’ll learn what helps you best.</p>}</CardContent></Card>
}
