"use client"

import { PolarAngleAxis, PolarGrid, PolarRadiusAxis, Radar, RadarChart, ResponsiveContainer, Tooltip } from "recharts"
import type { Mastery, Skill } from "@/lib/types"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export interface Props { mastery: Mastery }
const labels: Record<Skill, string> = { equivalence: "Equivalent", comparison: "Compare", number_line: "Number line", part_whole: "Part & whole", simplifying: "Simplify" }
const skills: Skill[] = ["equivalence", "comparison", "number_line", "part_whole", "simplifying"]
export function SkillRadar({ mastery }: Props) {
  const data = skills.map((skill) => ({ skill: labels[skill], mastery: Math.round(mastery[skill] * 100) }))
  return <Card className="rounded-3xl border-border/70 shadow-sm"><CardHeader><CardTitle>Your learning shape</CardTitle><CardDescription>Each point maps to a fraction skill.</CardDescription></CardHeader><CardContent><div className="h-[270px] w-full" role="img" aria-label="Radar chart of fraction skill mastery"><ResponsiveContainer width="100%" height="100%"><RadarChart data={data} outerRadius="72%"><PolarGrid stroke="var(--border)" /><PolarAngleAxis dataKey="skill" tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} /><PolarRadiusAxis domain={[0, 100]} tick={false} axisLine={false} /><Radar dataKey="mastery" name="Mastery" stroke="#7567e8" fill="#7567e8" fillOpacity={0.18} strokeWidth={2.5} /><Tooltip formatter={(value) => [`${value}%`, "Mastery"]} /></RadarChart></ResponsiveContainer></div></CardContent></Card>
}
