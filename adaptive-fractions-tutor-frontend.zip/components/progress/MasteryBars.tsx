"use client"

import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"
import type { Mastery, Skill } from "@/lib/types"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export interface Props { mastery: Mastery }
const labels: Record<Skill, string> = { equivalence: "Equivalent fractions", comparison: "Comparing", number_line: "Number line", part_whole: "Part & whole", simplifying: "Simplifying" }
const order: Skill[] = ["equivalence", "comparison", "number_line", "part_whole", "simplifying"]
function tone(value: number) { return value >= 0.7 ? "#31a879" : value >= 0.45 ? "#e8a23a" : "#e47778" }
export function MasteryBars({ mastery }: Props) {
  const data = order.map((skill) => ({ skill, label: labels[skill], value: Math.round(mastery[skill] * 100), fill: tone(mastery[skill]) }))
  return <Card className="rounded-3xl border-border/70 shadow-sm"><CardHeader><CardTitle>Skill mastery</CardTitle><CardDescription>How confident you’re feeling across each skill.</CardDescription></CardHeader><CardContent><div className="h-[250px] w-full" role="img" aria-label="Horizontal chart showing mastery percentage for five fraction skills"><ResponsiveContainer width="100%" height="100%"><BarChart data={data} layout="vertical" margin={{ top: 4, right: 32, left: 4, bottom: 4 }}><CartesianGrid horizontal={false} strokeDasharray="3 4" stroke="var(--border)" /><XAxis type="number" domain={[0, 115]} ticks={[0, 25, 50, 75, 100]} tickFormatter={(value: number) => `${value}%`} tick={{ fontSize: 11 }} axisLine={false} tickLine={false} /><YAxis type="category" dataKey="label" width={120} tick={{ fontSize: 12 }} axisLine={false} tickLine={false} /><Tooltip formatter={(value) => [`${value}%`, "Mastery"]} cursor={{ fill: "var(--muted)" }} /><Bar dataKey="value" radius={[0, 8, 8, 0]} barSize={19} label={{ position: "right", formatter: (value) => `${value ?? 0}%`, fill: "var(--foreground)", fontSize: 11 }}><Cell fill={data[0].fill} /><Cell fill={data[1].fill} /><Cell fill={data[2].fill} /><Cell fill={data[3].fill} /><Cell fill={data[4].fill} /></Bar></BarChart></ResponsiveContainer></div><div className="mt-3 flex flex-wrap gap-3 text-xs text-muted-foreground"><span className="flex items-center gap-1.5"><i className="size-2.5 rounded-full bg-emerald-500" />Strong</span><span className="flex items-center gap-1.5"><i className="size-2.5 rounded-full bg-amber-500" />Developing</span><span className="flex items-center gap-1.5"><i className="size-2.5 rounded-full bg-rose-400" />Needs practice</span></div></CardContent></Card>
}
